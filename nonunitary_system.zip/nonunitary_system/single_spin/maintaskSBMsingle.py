import numpy as np
from mainmd2funsbm import mainmd2funsbm
#from mainmd2funsbmdyn import mainmd2funsbmdyn
import time


#para: alpha
#para=np.array([[0.1,0.1,0.1]])

beta='Inf'
alpha=0.5           
#filename='Ohmic_alpha0p1_NN7_En10_En3_p0010.txt'
#filename='Ohmic_alpha0p3_NN7_En7_En3_p00009.txt'
filename='Ohmic_alpha0p5_NN7_En11_En3_p0020.txt'
#filename=['Ohmic_alpha0p1_NN7_En10_En3_p0010.txt','Ohmic_alpha0p3_NN7_En7_En3_p00009.txt','Ohmic_alpha0p5_NN7_En11_En3_p0020.txt']

MMlist=np.array([12],dtype='int')
#nn,mm=para.shape

ll=MMlist.size


for ii in range(0,ll):
    time0=time.time()
    mainmd2funsbm(MMlist[ii],alpha,filename)
    #mainmd2funsbmdyn(MMlist[ii],alpha,filename)
    time1=time.time()
    print(time1-time0)