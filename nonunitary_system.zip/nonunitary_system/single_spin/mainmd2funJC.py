from DavydovD2newv2 import DavydovD2
#from DavydovD2err import DavydovD2err
from observablesnewv2 import observables
from observablesnewv2 import cal_corrfunjc
import numpy as np
import scipy as sy
#from testlind import testlind
#import matplotlib.pyplot as plt
#import time

def mainmd2funsbm(MM,alpha,filename):
    sigmaz=np.array([[1,0],[0,-1]])
    sigmax=np.array([[0,1],[1,0]])
    w0=1.0/2
    Na=2
    wc=1.0
    wd=w0
    Ad=0.0*wd

    #gamma0=0.0
    #lambda_k=np.array([0.1])
    #omega_k=np.array([1.0])
    #Gamma_k=np.array([0.0])

    #Nmt=150
    #alpha=0.1
    #u_k=np.linspace(0,wc,Nmt+1)
    #lambda_k=np.sqrt(alpha*(u_k[1:]**2-u_k[:-1]**2))
    #omega_k=2/3*(u_k[1:]+u_k[:-1]**2/(u_k[1:]+u_k[:-1]))
    #Gamma_k=np.zeros((Nmt))

    #alpha=0.1
    #filename='Ohmic_alpha0p1_NN7_En10_En3_p0010.txt'
    #filename='Ohmic_alpha0p3_NN7_En7_En3_p00009.txt'
    #filename='Ohmic_alpha0p5_NN7_En11_En3_p0020.txt'
    tmp=np.loadtxt(filename)
    omega_k=tmp[0]
    Gamma_k=tmp[1]
    lambda_k=(tmp[2]+1j*tmp[3]).conj()

    #def jwfun(x,s,alpha,wc):
    #    return 2*alpha*x**s*np.exp(-x**2/wc**2)

    #kn=np.arange(0,Nmt+1)
    #xk=-wc*np.log(1-kn/Nmt)
    #omega_k=-wc*np.log(1-(kn[1:]-0.5)/Nmt)
    #tmp=np.zeros((Nmt))

    #for jj in range(0,Nmt):
    #    tmp[jj]=sy.integrate.quad(jwfun,xk[jj],xk[jj+1],args=(1.0,alpha,wc))[0]
        
    #lambda_k=np.sqrt(tmp)

    #alpha=0.5
    #lambda_k=np.array([0.3416 + 0.2358j,  -0.0138 - 0.0251j,   0.0139 + 0.0303j,  -0.0148 + 0.0152j,  -0.3884 - 0.4219j]).conj()
    #omega_k=np.array([0.3115,    3.1908,   -1.5026,   -0.0405,    1.2022])
    #Gamma_k=np.array([-0.6231,    1.7620,   -1.7547,   -0.4294,   -0.8596])

    #lambda_k=np.array([0.0029 + 0.0063j,0.1166 - 0.2546j,-0.0001 + 0.0197j,0.0154 - 0.0096j,-0.2485 + 0.0718j,0.0126 + 0.0145j,0.4733 - 0.3616j])
    #omega_k=np.array([-0.0305,    0.2015,   -0.6119,    5.0834,    1.9144,   -4.0270,    0.8384])
    #Gamma_k=np.array([0.3497,    0.5083,   -0.8832,    2.4191,   -0.9314,   -2.4676,   -0.7376])

    #alpha0.2 
    #Gamma_k=np.array([-0.8453,   -1.4818,   0.3639,   -1.5806,   -0.6293])
    #omega_k=np.array([1.2401,   -0.9459,    0.0021,    3.0103,    0.3627])
    #lambda_k=np.array([-0.0192 + 0.3456j,0.0107 - 0.0303j,0.0053 - 0.0322j,-0.0291 - 0.0165j,0.1286 - 0.2501j]).conj()

    #alpha=0.3
    #omega_k=np.array([0.3272,   -1.3362,   -0.0285,    3.1797,    1.2223])
    #lambda_k=np.array([0.3211 + 0.0778j,  -0.0269 - 0.0230j,   0.0053 - 0.0293j,   0.0246 + 0.0040j,-0.3624 - 0.2441j])
    #Gamma_k=np.array([0.6279,   -1.6843,   -0.4090,    1.7273,    0.8594])

    #omega_k=np.array([0.4563,   -0.3751,   -3.3295,    3.6626,    0.0335,    1.4046])
    #lambda_k=np.array([-0.0096 - 0.3936j,   0.0254 + 0.0110j,  -0.0231 - 0.0056j,  -0.0118 + 0.0131j, 0.0463 - 0.0428j,  0.1402 + 0.3492j])
    #Gamma_k=np.array([-0.6663,    0.8047,   -2.1155,   -1.9627,    0.3548,   -0.8766])

    #alpha=0.1


    #omega_k=np.array([3.0646,-1.4091,1.1411,-0.0428,0.2736])
    #lambda_k=np.array([0.0048 + 0.0294j,0.0286 + 0.0065j,0.2457 - 0.1049j,0.0185 - 0.0089j,0.1638 + 0.0475j])
    #Gamma_k=np.array([1.7142,-1.6985,0.8542,-0.4087,-0.6038])

    #omega_k=np.array([1.0479,    9.1827,   -4.1194,   -0.7860,   -0.0417,    0.2216,    2.7861])
    #lambda_k=np.array([0.2043 - 0.1930j,  -0.0230 + 0.0148j,   0.0138 - 0.0043j,   0.0115 + 0.0110j, 0.0007 - 0.0127j,   0.1188 - 0.0846j,  -0.0255 + 0.0168j]).conj()
    #Gamma_k=np.array([-0.8481,    2.4567,   -2.3598,   -0.9913,    0.3714,    0.5669,   -1.4523])

    #omega_k=np.array([0.0047,   -1.3002,   -0.3700,    1.3293,   -5.3577,    0.3661,   -2.2965,    4.0187])
    #Gamma_k=np.array([-0.3250,   -0.7720,    0.6783,   -0.8981,   -2.3241,   -0.6492,   -0.9092,   -2.2445])
    #lambda_k=np.array([-0.0181 - 0.0118j,   0.0080 - 0.0118j,  -0.0056 + 0.0051j,  -0.2402 - 0.0074j, 0.0005 + 0.0147j,   0.2062 + 0.0069j,   0.0187 - 0.0055j,  -0.0144 - 0.0223j])

    Hs=0.5*w0*sigmaz
    Ls=-1j*np.kron(np.eye(Na),Hs)+1j*np.kron(Hs.T,np.eye(Na))
    #VV=sigmaz
    VV=np.array([[0.0,1.0],[0.0,0.0]]).T
    #sp=np.array([[0.0,1.0],[0.0,0.0]])
    #sn=sp.T
    #Hs=0.5*sigmaz
    #Ls=-1j*np.kron(np.eye(Na),Hs)+1j*np.kron(Hs.T,np.eye(Na))+gamma0*(np.kron(sp.T,sn)-0.5*(np.kron(np.eye(2),sp@sn)+np.kron(sp@sn,np.eye(2))))
    #VV=sigmax



    VV1=np.kron(np.eye(Na),VV)
    VV2=np.kron(VV.conj(),np.eye(Na))

    #Ls2=Ls.conj().T@Ls
    #HV=0.5*(Hs@VV+VV@Hs)
    #HVd=0.5*(Hs@VV.conj().T+VV.conj().T@Hs)
    #Hs2=Hs@Hs
    ns=Hs.shape[0]
    Ns=Ls.shape[0]
    Nb=len(omega_k)
    #AA=(2*np.random.rand(MM,MM,ns,ns)-1)*1e-6
    #AA=0.5*(AA+np.transpose(AA,(1,0,3,2)))
    #AA=AA.reshape(MM,MM,Ns)
    #AA=(np.ones((MM,MM,Ns)))*1e-4
    AA=np.zeros((MM,MM,Ns))
    AA[0,0,0]=1.0 #np.array([1.0/2.0,1.0/2.0,1.0/2.0,1.0/2.0])
    FF=(2*np.random.rand(MM,Nb)-1)*1e-1
    FF[0,0:Nb]=(2*np.random.rand(1,Nb)-1)*1e-10
    GG=(2*np.random.rand(MM,Nb)-1)*1e-1
    GG[0,0:Nb]=(2*np.random.rand(1,Nb)-1)*1e-10
    y0=np.concatenate((AA.flatten(),FF.flatten(),FF.flatten()))+1j*0.0
    #yy=np.array([-0.2310+0.1513j,-0.2309+0.1513j,2.0522+0.4283j,-2.0521-0.42831j,-0.0771+0.1897j,0.0771-0.1897j])
    #observables(y0,MM,Ns,Nb)
    #dydt=DavydovD2(0.0,y0,MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k)
    #yy.shape()
    tf=30/w0
    tspan=np.linspace(0,tf,801)
    sol=sy.integrate.solve_ivp(DavydovD2,[tspan[0],tspan[-1]],y0,args=(MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k,Ad,wd),t_eval=tspan, rtol=1e-5,atol=1e-6)
    nt=len(sol.t)
    szlist=np.zeros((3,nt),dtype='complex128')
    phlist=np.zeros((nt,Nb),dtype='complex128')

    #pop,normf,h2mean,phnum=observables(20,yy,MM,Ns,Nb,Pn,lambda_k,omega_k,Hs2,VV,HV,HVd)

    for ii in range(0,nt):
        pop,popx,normf,phnum=observables(sol.y[:,ii],MM,Ns,Nb)
        #err=DavydovD2err(sol.t[ii],sol.y[:,ii],MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k,wd,Ad)
        szlist[:,ii]=np.array([pop,popx,normf]).copy()
        phlist[ii,:]=phnum.copy()



    gzzfun=np.zeros((nt,nt),dtype='complex128')
    for kk in range(0,nt-1):
        tmp=sol.y[:,kk].copy()
        AA0=tmp[0:(MM**2*Ns)].reshape(MM*MM,Ns)
        AA0[:,1]=AA0[:,0]
        AA0[:,0]=0.0*AA0[:,0]
        AA0[:,3]=AA0[:,2]
        AA0[:,2]=0.0*AA0[:,2]
        #AA0[:,[1,3]]=-AA0[:,[1,3]]
        yy0=np.block([AA0.flatten(),tmp[MM**2*Ns:]])
        soly2=sy.integrate.solve_ivp(DavydovD2,[tspan[kk],tspan[-1]],yy0,args=(MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k,Ad,wd),t_eval=tspan[kk:], rtol=1e-5,atol=1e-6)
        for mm in range(0,len(soly2.t)):
            if kk < nt-2:
                gzzfun[kk,kk+mm]=cal_corrfunjc(soly2.y[:,mm],MM,Ns,Nb)
            elif kk == nt-2:
                gzzfun[kk,-2]=cal_corrfunjc(soly2.y[:,0],MM,Ns,Nb)
                gzzfun[kk,-1]=cal_corrfunjc(soly2.y[:,-1],MM,Ns,Nb)


    gzzfun[-1,-1]=1.0

    TT1,TT2=np.meshgrid(tspan,tspan)

    gzzfun=(gzzfun+np.triu(gzzfun,1).conj().T)

    def corrfun(gzzfun,t1,t2,wk):
        return gzzfun*np.exp(-1j*wk*(t1-t2))

    Nmt=500
    kn=np.arange(0,Nmt+1)
    xk=-wc*np.log(1-kn/Nmt)
    wk=-wc*np.log(1-(kn[1:]-0.5)/Nmt)
    gk2=np.zeros((Nmt))

    def jwfun(x,s,alpha,wc):
        return 2*alpha*x**s*np.exp(-x**2/wc**2)

    for jj in range(0,Nmt):
        gk2[jj]=sy.integrate.quad(jwfun,xk[jj],xk[jj+1],args=(1.0,alpha,wc))[0]
    
    #gk2=np.zeros((Nmt))
    #gg=0.2


    #def jwfun(x,alpha,gg):
    #    return 2*alpha*x/((1.0-x**2)**2+(gg*x)**2)

    #for jj in range(0,Nmt):
    #    gk2[jj]=sy.integrate.quad(jwfun,xk[jj],xk[jj+1],args=(alpha,gg))[0]
        

    #sw=np.zeros((Nmt),dtype='complex128')

    #for ii in range(0,Nmt):
    #    sw[ii]=np.trapezoid(np.trapezoid(corrfun(TT1,TT2,wk[ii]),tspan),tspan)

    #tt2,szlist2,gxxfun=testlind(lambda_k[0],omega_k[0],Gamma_k[0]**2,gamma0,wd,Ad)

    nm=nt-1
    phlist2=np.zeros((nt-nm,Nmt),dtype='complex128')

    for jj in range(1,nt-nm+1):
        for kk in range(0,Nmt):
            phlist2[jj-1,kk]=np.trapezoid(np.trapezoid(corrfun(gzzfun[0:nm+jj,0:nm+jj],TT1[0:nm+jj,0:nm+jj],TT2[0:nm+jj,0:nm+jj],wk[kk]),tspan[0:jj+nm]),tspan[0:jj+nm]) 


    #plt.plot(wk,np.real(gk2*sw),omega_k,np.imag(gk2*sw))


    np.savez('MM'+str(MM)+'alpha'+str(alpha)+'PM'+str(Nb)+'Ad'+str(Ad)+'wd'+str(wd)+'single_JC.npz',tt=sol.t,szlist=szlist,phlist2=phlist2,gk2=gk2,wk=wk,gzzfun=gzzfun)
    #plt.plot(tspan,np.real(gzzfun[0]),tspan,np.imag(gzzfun[0]),tt2,np.real(gxxfun[0]),'--',tt2,np.imag(gxxfun[0]),':')
    #plt.plot(sol.t,np.real(phlist[:,0]),tspan[51:],np.real(0.25*lambda_k[0]**2*phlist2),':')
    #plt.plot(tspan,np.real(gzzfun[0]),tspan,np.imag(gzzfun[0]))

    #plt.show()