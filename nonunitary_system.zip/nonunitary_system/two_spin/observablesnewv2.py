import numpy as np

def observables(y,MM,Ns,Nb):

    AA=y[0:(MM**2*Ns)].reshape(MM*MM,Ns)
    FF=y[(MM**2*Ns):(Nb*MM+MM**2*Ns)].reshape(MM,Nb)
    GG=y[(Nb*MM+MM**2*Ns):].reshape(MM,Nb)

    mgf=np.exp(GG@FF.T-0.5*(np.sum(np.abs(GG)**2,axis=1).reshape(MM,1)+np.sum(np.abs(FF)**2,axis=1).reshape(1,MM)))
    pop=mgf.T.flatten()@AA@np.array([ 1.,  0.,  0.,  0.,  0.,  1.,  0.,  0.,  0.,  0., -1., 0.,  0., 0., 0., -1.])
    popx=mgf.T.flatten()@AA@np.array([0., 0., 1., 0., 0., 0., 0., 1., 1., 0., 0., 0., 0., 1., 0., 0.])
    normf=mgf.T.flatten()@AA@np.array([ 1.,  0.,  0.,  0.,  0.,  1.,  0.,  0.,  0.,  0., 1., 0.,  0., 0., 0., 1.])
    phnum=np.diag(GG.T@(mgf*np.sum(AA[:,::5],axis=1).reshape(MM,MM).T)@FF)

    return (pop,popx,normf,phnum)



def cal_corrfun(y,MM,Ns,Nb):
    
    AA=y[0:(MM**2*Ns)].reshape(MM*MM,Ns)
    FF=y[(MM**2*Ns):(Nb*MM+MM**2*Ns)].reshape(MM,Nb)
    GG=y[(Nb*MM+MM**2*Ns):].reshape(MM,Nb)

    mgf=np.exp(GG@FF.T-0.5*(np.sum(np.abs(GG)**2,axis=1).reshape(MM,1)+np.sum(np.abs(FF)**2,axis=1).reshape(1,MM)))


    corr=mgf.T.flatten()@AA@np.array([2.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0.,  0., 0.,  0., -2.])

    return corr

def cal_corrfunjc(y,MM,Ns,Nb):
    
    AA=y[0:(MM**2*Ns)].reshape(MM*MM,Ns)
    FF=y[(MM**2*Ns):(Nb*MM+MM**2*Ns)].reshape(MM,Nb)
    GG=y[(Nb*MM+MM**2*Ns):].reshape(MM,Nb)

    mgf=np.exp(GG@FF.T-0.5*(np.sum(np.abs(GG)**2,axis=1).reshape(MM,1)+np.sum(np.abs(FF)**2,axis=1).reshape(1,MM)))


    corr=mgf.T.flatten()@AA@np.array([0., 1., 1., 0., 0., 0., 0., 1., 0., 0., 0., 1., 0., 0., 0., 0.])

    return corr