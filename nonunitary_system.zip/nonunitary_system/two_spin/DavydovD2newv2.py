import numpy as np
import scipy as sy

def DavydovD2(t,y,MM,Ns,Nb,Ls,VV,WW,lambda_k,omega_k,gamma_k,Ad,wd):

    def colafun(fl,vv):
        return np.diagflat(fl.conj())@mfg@AAM@vv.T+mfg@np.diagflat(fl)@AAM@vv.conj()
    
    def colffun(fl,vv):
        tmp=AAM.conj()@vv@AAM.T
        return (np.diagflat(fl.conj())@(tmp*mfg))+(tmp.conj().T*mfg)@np.diagflat(fl)
    
    #Ls=LL-1j*Ad*np.cos(wd*t)*(VV-WW)

    AA=y[0:(MM**2*Ns)].reshape(MM,MM,Ns)
    FF=y[(MM**2*Ns):(Nb*MM+MM**2*Ns)].reshape(MM,Nb)
    GG=y[(Nb*MM+MM**2*Ns):].reshape(MM,Nb)

    tmpff=FF.conj()@FF.T
    mff=np.exp(tmpff-0.5*(np.diag(tmpff).reshape(MM,1)+np.diag(tmpff).reshape(1,MM)))
    tmpgg=GG@GG.conj().T
    mgg=np.exp(tmpgg-0.5*(np.diag(tmpgg).reshape(MM,1)+np.diag(tmpgg).reshape(1,MM)))

    tmp1=np.zeros((MM**2*Ns,MM*Nb))
    tmp2=np.zeros((MM**2*Ns,MM*Nb))

    for jj in range(0,MM):
        tmp1=tmp1+np.kron(np.kron(np.ones((MM**2,1)),AA[:,jj,:].T),np.ones((1,Nb)))*np.kron(np.ones((MM,1)),np.kron(mgg[jj,:].reshape(MM,1),np.ones((Ns,MM*Nb))))
        tmp2=tmp2+np.kron(np.ones((MM**2,1)),np.kron(AA[jj,:,:].T,np.ones((1,Nb))))*np.kron(mff[:,jj].reshape(MM,1),np.ones((MM*Ns,MM*Nb)))
    
    Lm01=tmp1*np.kron(np.kron(np.ones((1,MM)),FF.conj()),np.ones((MM*Ns,1)))*np.kron(mff,np.ones((MM*Ns,Nb)))
    Lm02=tmp2*np.kron(np.kron(np.ones((MM,1)),mgg.T),np.ones((Ns,Nb)))*np.kron(np.kron(np.ones((MM,MM)),GG.conj()),np.ones((Ns,1)))

    FFd1=np.kron(np.kron(np.ones((1,MM)),FF.conj()),np.ones((Nb,1)))
    GGd1=np.kron(np.kron(np.ones((1,MM)),GG.conj()),np.ones((Nb,1)))
    tmpAA=np.tensordot(AA.conj(),AA,axes=([-1],[-1]))
    mfg=np.kron(mff,mgg.T)+1e-10*np.eye(MM**2)
    Lm11=np.kron(np.sum(tmpAA*mfg.reshape(MM,MM,MM,MM),axis=(1,3)),np.ones((Nb,Nb)))*(np.kron(np.ones((MM,MM)),np.eye(Nb))+FFd1*FFd1.conj().T)
    Lm12=np.swapaxes(np.tensordot(np.tensordot(tmpAA*mfg.reshape(MM,MM,MM,MM),FF,axes=([2],[0])),GG.conj(),axes=([1],[0])),1,2).reshape(MM*Nb,MM*Nb)
    Lm22=np.kron(np.sum(tmpAA*mfg.reshape(MM,MM,MM,MM),axis=(0,2)),np.ones((Nb,Nb)))*(np.kron(np.ones((MM,MM)),np.eye(Nb))+GGd1*GGd1.conj().T)
    Matt=np.block([[np.kron(mfg,np.eye(Ns)),Lm01,Lm02],
                   [Lm01.conj().T,Lm11,Lm12],
                   [Lm02.conj().T,Lm12.conj().T,Lm22]])
    #Matt=np.block([[np.kron(mfg,np.eye(Ns)),Lm01,Lm02],
    #               [Lm01.conj().T,Lm11,Lm12]])

    AAM=AA.reshape(MM**2,Ns)
    lambda_kt=lambda_k*np.exp(-1j*omega_k*t)
    gamma_kt=gamma_k*np.exp(-1j*omega_k*t)
    FL=FF@lambda_kt
    Fn=FF@gamma_kt
    GL=GG@lambda_kt.conj()
    Gm=GG@gamma_kt.conj()
    FFklnm=np.kron(np.ones((MM**2,1)),np.kron(Fn.reshape(1,MM),Gm.reshape(1,MM)))-0.5*(np.kron(np.kron(Fn.conj().reshape(MM,1),Fn.reshape(1,MM)),np.ones((MM,MM)))+np.kron(np.ones((MM,MM)),np.kron(Gm.conj().reshape(MM,1),Gm.reshape(1,MM))))

    colA=mfg@AAM@Ls.T-0.5j*colafun(np.kron(FL.reshape(MM,1),np.ones((MM,1))),VV)+0.5j*colafun(np.kron(np.ones((MM,1)),GL.reshape(MM,1)),WW)+(FFklnm*mfg)@AAM

    ALA=AAM.conj()@Ls@AAM.T
    AeA=AAM.conj()@AAM.T
    
    colF=(np.sum(((ALA+AeA*FFklnm)*mfg-0.5j*colffun(np.kron(FL.reshape(MM,1),np.ones((MM,1))),VV)+0.5j*colffun(np.kron(np.ones((MM,1)),GL.reshape(MM,1)),WW)).reshape(MM,MM,MM,MM),axis=(1,3)))@FF+np.kron(np.sum(((AAM.conj()@VV@AAM.T)*mfg).reshape(MM,MM,MM,MM),axis=(1,2,3)).reshape(MM,1),-0.5j*lambda_kt.conj().reshape(1,Nb))+np.kron(-0.5*np.sum(np.tensordot((AeA*mfg).reshape(MM,MM,MM,MM),Fn,axes=([2],[0])),axis=(1,2)).reshape(MM,1),gamma_kt.conj().reshape(1,Nb))

    colG=(np.sum(((ALA+AeA*FFklnm)*mfg-0.5j*colffun(np.kron(FL.reshape(MM,1),np.ones((MM,1))),VV)+0.5j*colffun(np.kron(np.ones((MM,1)),GL.reshape(MM,1)),WW)).reshape(MM,MM,MM,MM),axis=(0,2)))@GG+np.kron(np.sum(((AAM.conj()@WW@AAM.T)*mfg).reshape(MM,MM,MM,MM),axis=(0,2,3)).reshape(MM,1),0.5j*lambda_kt.reshape(1,Nb))+np.kron(-0.5*np.sum(np.tensordot((AeA*mfg).reshape(MM,MM,MM,MM),Gm,axes=([3],[0])),axis=(0,2)).reshape(MM,1),gamma_kt.reshape(1,Nb))

    tmpdy=sy.linalg.solve(Matt+1e-10*np.eye(MM**2*Ns+2*MM*Nb),np.block([colA.flatten(),colF.flatten(),colG.flatten()]))

    Akl=tmpdy[0:(MM**2*Ns)].reshape(MM**2*Ns,1)
    dFF=tmpdy[(MM**2*Ns):(Nb*MM+MM**2*Ns)].reshape(MM,Nb)
    dGG=tmpdy[(Nb*MM+MM**2*Ns):].reshape(MM,Nb)
    dAA=Akl+AA.reshape(MM**2*Ns,1)*np.kron(np.kron(np.real(np.sum(dFF*FF.conj(),axis=1,keepdims=True)),np.ones((MM,1)))+np.kron(np.ones((MM,1)),np.real(np.sum(dGG*GG.conj(),axis=1,keepdims=True))),np.ones((Ns,1)))

    return np.block([dAA.flatten(),tmpdy[MM**2*Ns:].flatten()])