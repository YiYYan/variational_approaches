import numpy as np
from etafun import etafun
from FFmat import FFmat
from smallmatrixcorrfun import Matrixfun, corrfun, intcorr, dynfun
#from smallmatrixnew import Matrixfun, dynfun
#import matplotlib.pyplot as plt

import time as time
t0=time.time()
alpha=0.3
beta=5.0
wc=1.0
dt=1.0
Delta=0.1
Ad=0.05
wd=Delta
NN=300
dKmax=8
sdim=4
etamatkk,etamatNk,etamatkkp,etamatN0=etafun(alpha,beta,wc,dt,dKmax,10*wc)

skp=np.array([1.0,1.0,-1.0,-1.0]).reshape(1,sdim)
skn=np.array([1.0,-1.0,1.0,-1.0]).reshape(1,sdim)
sigmax=np.array([[0.0,1.0],[1.0,0.0]])
sigmaz=np.array([[1.0,0.0],[0.0,-1.0]])
Hs=-0.5*Delta*sigmax
Kt=7
kxv=np.arange(-Kt,Kt+1)
xx,yy=np.meshgrid(kxv,kxv)
ikxywdt=(1.0j*(-xx+yy)*wd*dt).reshape(-1)
Nk=kxv.size
Nk2=Nk**2
HF=np.kron(np.eye(Nk),Hs)+np.kron(np.diag(kxv),wd*np.eye(2))+0.5*Ad*(np.kron(np.diag(np.ones((Nk-1)),1)+np.diag(np.ones((Nk-1)),-1),sigmaz))
UHmat,I0LR,I0C,IdkC,IdkR,IdkLR=FFmat(etamatkk,etamatNk,etamatkkp,etamatN0,skp,skn,sdim,dKmax,HF,dt)


#MMatrix0=np.zeros((dKmax,sdim,sdim),dtype='complex128')
#MMatrix1=np.zeros((dKmax,sdim,sdim),dtype='complex128')

  
#AA10=np.diagflat(I0C)@(KKmat*IdkR[0])@np.diagflat(I0LR)
#AAC=np.diagflat(I0C)@(KKmat*IdkC[0])

#if not AAC.flags['C_CONTIGUOUS']:
#    AAC = np.ascontiguousarray(AAC)
#if not AA10.flags['C_CONTIGUOUS']:
#    AA10 = np.ascontiguousarray(AA10)

KKmat=np.zeros((sdim*Nk2,sdim*Nk2),dtype='complex128')

s0lp=np.array([0,0,1,1])
s0ln=np.array([0,1,0,1])
for jj in range(0,4):
    s1n=s0ln[jj]
    s1p=s0lp[jj]
    for kk in range(0,4):
        s0n=s0ln[kk]
        s0p=s0lp[kk]
        KKmat[jj*Nk2:(jj+1)*Nk2,Nk2*kk:(kk+1)*Nk2]=np.kron(UHmat[s1p::2,s0p::2],(UHmat.conj().T)[s0n::2,s1n::2].T)

AA10=np.kron(I0C.reshape(sdim,1)*IdkR[0]*I0LR.reshape(1,sdim),np.ones((Nk2,Nk2)))*KKmat
AAC=np.kron(I0C.reshape(sdim,1)*IdkC[0],np.ones((Nk2,Nk2)))*KKmat

rpsi0=np.zeros((Nk,Nk),dtype='complex128')
rpsi0[Kt,Kt]=1.0

rho0=np.kron(np.array([1.0,0.0,0.0,0.0],dtype='complex128'),rpsi0.reshape(-1))

MMatrix0=Matrixfun(dKmax,sdim,Nk2,IdkR,IdkC,AAC,AA10)

rhot=dynfun(MMatrix0[1:,0,:,:],MMatrix0[0,:,:,:],dKmax,NN,Nk2,rho0,ikxywdt,sdim)

corr=corrfun(MMatrix0,dKmax,NN,Nk2,sdim,rho0,ikxywdt)

gzzfun=corr+np.triu(corr,1).T.conj()

szlist=np.vstack((rhot[0]-rhot[3],rhot[1]+rhot[2],rhot[0]+rhot[3]))


#print(str(MMatrix0[2]))
#print(str(MMatrix1[2]))
tspan=np.arange(0,NN+1)*dt
#plt.plot(tspan,np.real(szlist))

omega_k=np.linspace(0,wc,300)
#lambda_k=np.array([alpha])
sw=intcorr(gzzfun,tspan,omega_k,NN+1)

np.savez('SMatPItest'+'dKmax'+str(dKmax)+'alpha'+str(alpha)+'beta'+str(beta)+'Ad'+str(Ad)+'wd'+str(wd)+'Kt'+str(Kt)+'dt'+str(dt)+'new_sbmFT.npz',tt=tspan,szlist=szlist,wk=omega_k,corr=gzzfun,sw=sw)

t1=time.time()
print("time: "+str(t1-t0))
