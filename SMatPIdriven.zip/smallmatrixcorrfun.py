import numpy as np
from numba import njit, jit

@njit("int64[:](int64[:],int64)")
def pathadd(path,kk):
    if path[kk]==3:
        path[kk]=0
        pathadd(path,kk-1)
    else: 
        path[kk]=path[kk]+1
    return path

@njit('complex128[:,:](int64[:],int64,int64,int64,complex128[:,:,:],complex128[:,:,:],complex128[:,:],complex128[:,:])')
def iMMatfun(path,sk,s0,kk,IdkC,IdkR,AAC,mmatlistk0):
    tmp=1.0
    tmp2=np.zeros((2,kk-2),dtype='complex128')
    for jj in np.arange(2,kk):
        tmp=tmp*IdkC[jj-1,sk,path[-jj]]
        if jj-2==0:
            tmp2[:,jj-2]=np.array([IdkR[kk-jj,path[-1],s0]-1,IdkC[kk-jj,path[-1],s0]-1])
        else:
            tmp2[:,jj-2]=IdkC[kk-jj,path[-1],path[jj-3]]-1

    tmp3=tmp
    mmatlist=np.zeros((2,kk-1),dtype='complex128')
    for nn in np.arange(0,kk-1):
        if nn==0:
            mmatlist[:,nn]=np.array([IdkR[kk-2,path[-1],s0]*mmatlistk0[0,0]*tmp,IdkC[kk-2,path[-1],s0]*mmatlistk0[1,0]*tmp])
        elif nn==kk-2:
            mmatlist[:,nn]=np.sum(mmatlistk0*tmp2,axis=1)
        else:
            tmp3=tmp3/IdkC[kk-nn-1,sk,path[nn-1]]
            mmatlist[:,nn]=np.sum(mmatlistk0[:,0:(nn+1)]*np.hstack((tmp2[:,0:nn],np.array([[IdkC[kk-2-nn,path[-1],path[nn-1]]],[IdkC[kk-2-nn,path[-1],path[nn-1]]]]))),axis=1)*tmp3

    return mmatlist



#@njit('complex128[:](int64[:],int64,complex128[:,:,:],complex128[:,:,:],complex128[:,:],complex128[:,:])')
#def SMatfun(path,kk,IdkR,IdkC,AAC,AA10):

    #tmp=AAC[path[3],path[2]]*AAC[path[2],path[1]]*AA10[path[1],path[0]]
    #tmpk1=AAC[path[3],path[2]]*AAC[path[2],path[1]]*AAC[path[1],path[0]]
    #mmatlistk0=np.array([[IdkR[1,path[2],path[0]]*IdkC[1,path[3],path[1]],(IdkR[1,path[2],path[0]]-1)],
    #                     [IdkC[1,path[2],path[0]]*IdkC[1,path[3],path[1]],(IdkC[1,path[2],path[0]]-1)]])

    #if kk==3:
    #    tmpMMk0_sks0=np.sum(mmatlistk0*np.array([[IdkR[2,path[3],path[0]]-1,IdkC[1,path[3],path[1]]-1],
    #                                             [IdkC[2,path[3],path[0]]-1,IdkC[1,path[3],path[1]]-1]]),axis=1)
    #    return tmpMMk0_sks0
    #else:
    #    for nn in np.arange(4,kk+1):
    #        mmatlistk0=iMMatfun(path[1:nn],path[nn],path[0],nn,IdkC,IdkR,AAC,mmatlistk0)

    #    tmp2=np.zeros((2,kk-1),dtype='complex128')
    #    for jj in np.arange(0,kk-1):
    #        if jj==0:
    #            tmp2[:,jj]=np.array([IdkR[kk-jj-1,path[-1],path[0]]-1,IdkC[kk-jj-1,path[-1],path[0]]-1])
    #        else:
    #            tmp2[:,jj]=IdkC[kk-jj-1,path[-1],path[jj]]-1
        
    #    tmpMMk0_sks0=np.sum(tmp2*mmatlistk0,axis=1)

    #    return tmpMMk0_sks0

@njit('complex128[:,:,:,:](int64,int64,int64,complex128[:,:,:],complex128[:,:,:],complex128[:,:],complex128[:,:])')
def Matrixfun(dKmax,sdim,Nk2,IdkR,IdkC,AAC,AA10):
    
    tmpMMk0=np.zeros((dKmax+1,dKmax,Nk2*sdim,Nk2*sdim),dtype='complex128')
    
    kk_node=1
    skp=np.array([1.0,1.0,-1.0,-1.0])

    tmpMMk0[1,0,:,:]=AA10
    tmpMMk0[2,0,:,:]=np.kron(IdkR[1]-1,np.ones((Nk2,Nk2)))*(AAC@AA10)
    tmpMMk0[2,1,:,:]=np.kron(IdkR[1]-1,np.ones((Nk2,Nk2)))*((np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*AAC)@AA10)
    tmpMMk0[0,0,:,:]=AAC
    tmpMMk0[0,1,:,:]=np.kron(IdkC[1]-1,np.ones((Nk2,Nk2)))*(AAC@AAC)
    tmpMMk0[1,1,:,:]=np.kron(IdkC[1]-1,np.ones((Nk2,Nk2)))*((np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*AAC)@AAC)

    path=np.zeros((dKmax+1),dtype='int64')
    for jj in range(0,4**(dKmax+1)):
        tmpk0=AAC[path[-4]*Nk2:(path[-4]+1)*Nk2,Nk2*path[-3]:Nk2*(path[-3]+1)]@AAC[path[-3]*Nk2:(path[-3]+1)*Nk2,Nk2*path[-2]:Nk2*(path[-2]+1)]@AA10[Nk2*path[-2]:Nk2*(path[-2]+1),Nk2*path[-1]:Nk2*(path[-1]+1)]
        tmpk1=AAC[path[-4]*Nk2:(path[-4]+1)*Nk2,Nk2*path[-3]:Nk2*(path[-3]+1)]@AAC[path[-3]*Nk2:(path[-3]+1)*Nk2,Nk2*path[-2]:Nk2*(path[-2]+1)]@AAC[Nk2*path[-2]:Nk2*(path[-2]+1),Nk2*path[-1]:Nk2*(path[-1]+1)]

        mmatlistk0=np.array([[IdkR[1,path[-3],path[-1]]*IdkC[1,path[-4],path[-2]],(IdkR[1,path[-3],path[-1]]-1)],
                             [IdkC[1,path[-3],path[-1]]*IdkC[1,path[-4],path[-2]],(IdkC[1,path[-3],path[-1]]-1)]])
        if kk_node<=256:
            tmpMM=np.sum(mmatlistk0*np.array([[IdkR[2,path[-4],path[-1]]-1,IdkC[1,path[-4],path[-2]]-1],
                                                  [IdkC[2,path[-4],path[-1]]-1,IdkC[1,path[-4],path[-2]]-1]]),axis=1)
            for Nk in np.arange(0,3):
                if Nk==0:
                    tmpMMk0[3,Nk,path[-4]*Nk2:(path[-4]+1)*Nk2,path[-1]*Nk2:(path[-1]+1)*Nk2]+=tmpk0*tmpMM[0]
                    tmpMMk0[Nk,2,path[-4]*Nk2:(path[-4]+1)*Nk2,path[-1]*Nk2:(path[-1]+1)*Nk2]+=tmpk1*tmpMM[1]
                else:
                    tmpMMk0[3,Nk,path[-4]*Nk2:(path[-4]+1)*Nk2,path[-1]*Nk2:(path[-1]+1)*Nk2]+=skp[path[-Nk-1]]*tmpk0*tmpMM[0]
                    tmpMMk0[Nk,2,path[-4]*Nk2:(path[-4]+1)*Nk2,path[-1]*Nk2:(path[-1]+1)*Nk2]+=skp[path[-Nk-1]]*tmpk1*tmpMM[1]                   
        
        for kk in range(4,dKmax+1):
            tmpk0=AAC[path[-kk-1]*Nk2:(path[-kk-1]+1)*Nk2,path[-kk]*Nk2:(path[-kk]+1)*Nk2]@tmpk0
            tmpk1=AAC[path[-kk-1]*Nk2:(path[-kk-1]+1)*Nk2,path[-kk]*Nk2:(path[-kk]+1)*Nk2]@tmpk1
            path_kk=path[-(kk+1):]
            mmatlistk0=iMMatfun(path_kk[1:-1][::-1],path[-kk-1],path[-1],kk,IdkC,IdkR,AAC,mmatlistk0)
            if kk_node<=4**(kk+1):
                tmp2=np.zeros((2,kk-1),dtype='complex128')
                for jj in np.arange(0,kk-1):
                    if jj==0:
                        tmp2[:,jj]=np.array([IdkR[kk-jj-1,path[-kk-1],path[-1]]-1,IdkC[kk-jj-1,path[-kk-1],path[-1]]-1])
                    else:
                        tmp2[:,jj]=IdkC[kk-jj-1,path[-kk-1],path[-jj-1]]-1
        
                tmpMM=np.sum(tmp2*mmatlistk0,axis=1)
                for Nk in range(0,kk):
                    if Nk==0:
                        tmpMMk0[kk,Nk,Nk2*path[-kk-1]:Nk2*(path[-kk-1]+1),path[-1]*Nk2:Nk2*(path[-1]+1)]+=tmpk0*tmpMM[0]
                        tmpMMk0[Nk,kk-1,Nk2*path[-kk-1]:Nk2*(path[-kk-1]+1),path[-1]*Nk2:Nk2*(path[-1]+1)]+=tmpk1*tmpMM[1]
                    else:
                        tmpMMk0[kk,Nk,Nk2*path[-kk-1]:Nk2*(path[-kk-1]+1),path[-1]*Nk2:Nk2*(path[-1]+1)]+=skp[path[-Nk-1]]*tmpk0*tmpMM[0]
                        tmpMMk0[Nk,kk-1,Nk2*path[-kk-1]:Nk2*(path[-kk-1]+1),path[-1]*Nk2:Nk2*(path[-1]+1)]+=skp[path[-Nk-1]]*tmpk1*tmpMM[1]
            
            
        path=pathadd(path,dKmax)
        kk_node=kk_node+1

    return tmpMMk0

@njit('complex128[:](int64,int64,complex128[:],complex128[:],int64)')
def partr(sdim,Nk2,rhofs,ikxywdt,nn):
    rhofinal=np.zeros((sdim),dtype='complex128')
    for jj in range(0,sdim):
        rhofinal[jj]=np.sum(rhofs[jj*Nk2:(jj+1)*Nk2]*np.exp(ikxywdt*nn))
    
    return rhofinal


@njit('complex128[:,:](complex128[:,:,:],complex128[:,:,:],int64,int64,int64,complex128[:],complex128[:],int64)')
def dynfun(MMmatrix0,MMmatrix1,dKmax,NN,Nk2,rho0,ikxywdt,sdim):
    UUmat=np.zeros((dKmax,Nk2*sdim,Nk2*sdim),dtype='complex128')
    UUmat[0]=MMmatrix0[0]
    rhot=np.zeros((sdim,NN+1),dtype='complex128')
    rhot[:,0]=partr(sdim,Nk2,rho0,ikxywdt,0)
    rhot[:,1]=partr(sdim,Nk2,UUmat[0]@rho0,ikxywdt,1)
    for rr in np.arange(1,dKmax):
        UUmat[rr]=MMmatrix0[rr]
        for mm in np.arange(0,rr):
            UUmat[rr]=UUmat[rr]+MMmatrix1[rr-mm-1]@UUmat[mm]

        rhot[:,rr+1]=partr(sdim,Nk2,UUmat[rr]@rho0,ikxywdt,rr+1)

    for rr in np.arange(dKmax,NN):
        UUtmp=MMmatrix1[-1]@UUmat[0]
        for mm in np.arange(0,dKmax-1):
            UUtmp=UUtmp+MMmatrix1[dKmax-mm-2]@UUmat[mm+1]
        UUmat[0:-1,:,:]=UUmat[1:,:,:]
        UUmat[-1,:,:]=UUtmp
        rhot[:,rr+1]=partr(sdim,Nk2,UUtmp@rho0,ikxywdt,rr+1)

    return rhot



@njit('complex128[:,:](complex128[:,:,:,:],int64,int64,int64,int64,complex128[:],complex128[:])')
def corrfun(MMmatrix00,dKmax,NN,Nk2,sdim,rho00,ikxywdt):
    UUmat=np.zeros((dKmax,Nk2*sdim,Nk2*sdim),dtype='complex128')
    corr=np.zeros((NN+1,NN+1),dtype='complex128')
    corr[0,0]=1.0
    for Nk in np.arange(0,NN+1):
        if Nk==0:
            rho0=np.kron(np.array([1.0,1.0,-1.0,-1.0]),np.ones((Nk2)))*rho00
        else:
            rho0=rho00
        if Nk==1:
            UUmat[0]=np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*MMmatrix00[1,0]
        else:
            UUmat[0]=MMmatrix00[1,0]
    
        if 1>=Nk:
            rhot=partr(sdim,Nk2,UUmat[0]@rho0,ikxywdt,0)
            corr[Nk,1]=rhot[0]-rhot[3]

        for rr in np.arange(1,dKmax):
            if Nk>dKmax or rr+1<Nk:
                UUmat[rr]=MMmatrix00[rr+1,0]
            elif rr+1==Nk:
                UUmat[rr]=np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*MMmatrix00[rr+1,0]
            else:
                UUmat[rr]=MMmatrix00[rr+1,Nk]
            for mm in np.arange(0,rr):
                if rr+1<Nk or mm+1>=Nk:
                    MMmatrix1=MMmatrix00[0,rr-mm-1]
                elif rr+1==Nk:
                    MMmatrix1=np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*MMmatrix00[0,rr-mm-1]
                else:
                    MMmatrix1=MMmatrix00[Nk-1,rr-mm-1]
                UUmat[rr]=UUmat[rr]+MMmatrix1@UUmat[mm]

            if rr+1>=Nk:
                rhot=partr(sdim,Nk2,UUmat[rr]@rho0,ikxywdt,rr+1)
                corr[Nk,rr+1]=rhot[0]-rhot[3]

        for rr in np.arange(dKmax,NN):
            if rr+1<Nk or rr-dKmax+1>=Nk:
                UUtmp=MMmatrix00[0,-1]@UUmat[0]
            elif rr+1==Nk:
                UUtmp=(np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*MMmatrix00[0,-1])@UUmat[0]
            else:
                UUtmp=MMmatrix00[Nk-rr+dKmax-1,-1]@UUmat[0]
            for mm in np.arange(0,dKmax-1):
                if rr+1<Nk or rr-dKmax+mm+2>=Nk:
                    MMmatrix11=MMmatrix00[0,dKmax-mm-2]
                elif rr+1==Nk:
                    MMmatrix11=np.kron(np.array([[1.0],[1.0],[-1.0],[-1.0]]),np.ones((Nk2,1)))*MMmatrix00[0,dKmax-mm-2]
                else:
                    MMmatrix11=MMmatrix00[Nk-rr+dKmax-mm-2,dKmax-mm-2]

                UUtmp=UUtmp+MMmatrix11@UUmat[mm+1]
            
            UUmat[0:-1,:,:]=UUmat[1:,:,:]
            UUmat[-1,:,:]=UUtmp
            if rr+1>=Nk:
                rhot=partr(sdim,Nk2,UUtmp@rho0,ikxywdt,rr+1)
                corr[Nk,rr+1]=rhot[0]-rhot[3]

    return corr

def intcorr(corrf,tspan,omega_k,Nt):
    Nb=omega_k.size
    TT1,TT2=np.meshgrid(tspan,tspan)
    sw=np.zeros((Nt-10,Nb),dtype='complex128')
    for nn in np.arange(10,Nt):
        for mm in range(0,Nb):
            sw[nn-10,mm]=0.25*np.trapezoid(np.trapezoid(corrf[0:nn+1,0:nn+1]*np.exp(-1j*omega_k[mm]*(TT1[0:nn+1,0:nn+1]-TT2[0:nn+1,0:nn+1])),tspan[0:nn+1]),tspan[0:nn+1])

    return sw