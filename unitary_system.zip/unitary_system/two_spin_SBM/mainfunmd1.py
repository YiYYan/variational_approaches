import numpy as np
from DavydovD1new import DavydovD1new
from observables import observables, corrfun
#import matplotlib.pyplot as plt
import scipy as sy
import time

def mainfunmd1(para):   
    
    start_time=time.time()
    sigmaz=np.array([[1.0,0.0],[0.0,-1.0]])
    sigmax=np.array([[0.0,1.0],[1.0,0.0]])
    alpha=para[0]
    Delta=0.25
    lambda0=para[2]
    wcav=para[3]
    Vd=para[4]
    MM=int(para[1])
    NN=int(para[-2])
    Ns=4
    wc=1.0
    Nmt=int(para[-1])

    #using linear discretization

    #u_k=np.linspace(0,wc,Nmt+1)
    #lambda_k=np.sqrt(alpha*(u_k[1:]**2-u_k[:-1]**2))
    #omega_k=2/3*(u_k[1:]+u_k[:-1]**2/(u_k[1:]+u_k[:-1]))


    def jwfun(x,s,alpha,wc):
        return 2*alpha*x**s*wc**(1-s)*np.exp(-x**2/wc**2)

    #wmax=6.0
    #Nf=1-np.exp(-wmax)
    kn=np.arange(0,Nmt+1)
    xk=-wc*np.log(1-kn/Nmt)
    omega_k=-wc*np.log(1-(kn[1:]-0.5)/Nmt)
    lambda_k=np.zeros((Nmt))

    for jj in range(0,Nmt):
        tmp=sy.integrate.quad(jwfun,xk[jj],xk[jj+1],args=(1,alpha,wc))
        lambda_k[jj]=tmp[0]

    lambda_k=np.sqrt(lambda_k)



    #omega_k=np.block([omega_k,wcav])
    #lambda_k=np.block([lambda_k,lambda0])

    ac=np.diag(np.sqrt(np.arange(1,NN)),1)

    ada=np.diag(np.arange(0,NN))


    Hs=np.kron(np.eye(NN),-0.5*Delta*(np.kron(sigmax,np.eye(2))+np.kron(np.eye(2),sigmax))+Vd*np.kron(sigmaz,sigmaz))+np.kron(wcav*ada,np.eye(Ns))+np.kron(0.5*lambda0*(ac+ac.T),np.kron(sigmax,np.eye(2))+np.kron(np.eye(2),sigmax))
    sz1=np.kron(sigmaz,np.eye(2))
    sz2=np.kron(np.eye(2),sigmaz)
    VV1=sz1+sz2
    V1j=np.diag(VV1)

    Sz1=np.kron(np.eye(NN),sz1)
    Sz2=np.kron(np.eye(NN),sz2)
    Phc=np.kron(ada,np.eye(Ns))
    Sx1=np.kron(np.eye(2),sigmax)
    
    VV2=Sz1+Sz2
    HV1=0.5*(Hs@VV2+VV2@Hs)
    Hs2=Hs@Hs
    Nb=len(omega_k)
    AA=(2*np.random.rand(MM,Ns*NN)-1)*1e-4
    FF=(2*np.random.rand(MM*Ns,Nb)-1)*1e-1

    #psi0=np.kron(np.blcok([1.0,np.zeros((1,NN-1))]),np.array([0.0,0.0,0.0,1.0]))

    AA[0,0]=1.0
    FF[::MM,:]=(2*np.random.rand(1,Nb)-1)*1e-8
    y0=np.block([AA.flatten(order='F'),FF.flatten()])+1j*0.0
    
    #pop1,pop2,pop3,normf,h2mean,phnum=observables(0.0,y0,Hs2,HV1,VV1,omega_k,lambda_k,Ns,NN,MM,Nb,Sz1,Sz2,Phc)


    Dim=Ns*MM
    tspan=[0,30/Delta]
    sol=sy.integrate.solve_ivp(DavydovD1new,tspan,y0,args=(Hs,V1j,lambda_k,omega_k,Ns,NN,MM,Nb,Dim),t_eval=np.linspace(0,30/Delta,501),rtol=1e-5,atol=1e-6)
    nt=len(sol.t)
    szlist=np.zeros((5,nt),dtype='complex128')
    phlist=np.zeros((nt,Nb),dtype='complex128')


    for ii in range(0,nt):
        pop1,pop2,pop3,normf,h2mean,phnum=observables(sol.t[ii],sol.y[:,ii],Hs2,HV1,VV1,omega_k,lambda_k,Ns,NN,MM,Nb,Sz1,Sx1,Phc)
        #err=DavydovD1e1qerr(sol.t[ii],sol.y[:,ii],Hs,V1j,lambda_k,omega_k,Ns,MM,Nb,Dim)
        szlist[:,ii]=np.array([pop1,pop2,pop3,normf,h2mean]).copy()
        phlist[ii,:]=phnum.copy()

    tmp=sol.y[:,250].copy()
    AA0=tmp[0:(Ns*MM)].reshape(MM,Ns,order='F')
    AA0[:,0]=2*AA0[:,0]
    AA0[:,1:2]=1e-6*AA0[:,1:2]
    AA0[:,3]=-2*AA0[:,3]
    yy0=np.block([AA0.flatten(order='F'),tmp[Ns*MM:]])
    sol2=sy.integrate.solve_ivp(DavydovD1new,[sol.t[250],sol.t[-1]],yy0,args=(Hs,V1j,lambda_k,omega_k,Ns,NN,MM,Nb,Dim),t_eval=sol.t[250:],rtol=1e-5,atol=1e-6)
    nt2=len(sol2.t)
    corr=np.zeros((nt2),dtype='complex128')

    for jj in range(0,nt2):
        corr[jj]=corrfun(sol.y[:,250+jj],sol2.y[:,jj],MM,Ns,Nb,sz1+sz2)



    np.savez('MM_'+str(MM)+'alpha_'+str(alpha)+'NoM'+str(Nb)+'Ohmicv2.npz',tt=sol.t,szlist=szlist,phlist=phlist,wk=omega_k,corr=corr)

    end_time=time.time()
    print(end_time-start_time)

    #plt.plot(sol.t,szlist[0])
    #plt.show()
