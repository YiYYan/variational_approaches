import numpy as np
def observables(t,y,Hs2,HV1,V1,omega_k,lambda_k,Ns,NN,MM,Nb,sz1,sz2,ada):
    def sysfun(OO):
        return np.sum(Rhov*np.kron(np.eye(NN),Smat)*np.kron(OO,np.ones((MM,MM))))
    
    #def hvmean(HV,FL,GL,CL):
    #    return (np.sum(Rhov*Smat*np.kron(HV,np.ones((MM,MM)))*(FL.conj()+FL.T))+
    #            np.sum(np.kron(HV,np.ones((MM,1)))*np.kron(Avec.conj(),np.ones((1,Ns)))*Tmat*(FC*(np.kron(FL.conj(),np.ones((1,Ns)))+np.kron(np.ones((MM*Ns,1)),GL.T))+np.kron(np.ones((MM*Ns,1)),CL.T)))+
    #            np.sum(np.kron(HV,np.ones((1,MM)))*np.kron(np.ones((Ns,1)),Avec.T)*Tmat.conj().T*(FC.conj().T*(np.kron(np.ones((Ns,1)),FL.T)+np.kron(GL.conj(),np.ones((1,Ns*MM))))+np.kron(CL.conj(),np.ones((1,Ns*MM)))))+
    #            np.sum(HV*Rmat*((CsCt+GC*GC.conj().T)*(GL.conj()+GL.T)+GC*np.kron(CL.conj(),np.ones((1,Ns)))+GC.conj().T*np.kron(np.ones((Ns,1)),CL.T))))

    #def h12mean(V1,V2,FL1,GL1,CL1,FL2,GL2,CL2,lambda_kt1,lambda_kt2):
    #    return (np.sum(np.kron(V1@V2,np.ones((MM,MM)))*np.kron(Avec.conj(),Avec.T)*Smat*(FL1.conj()+FL1.T)*(FL2.conj()+FL2.T))+
    #            np.sum(np.kron(V1@V2,np.ones((MM,1)))*np.kron(Avec.conj(),np.ones((1,Ns)))*Tmat*(FC*(FL1.conj()+np.kron(np.ones((MM*Ns,1)),GL1.T))*(FL2.conj()+np.kron(np.ones((MM*Ns,1)),GL2.T))+
    #            np.kron(np.ones((MM*Ns,1)),CL1.T)*(FL2.conj()+np.kron(np.ones((MM*Ns,1)),GL2.T))+np.kron(np.ones((MM*Ns,1)),CL2.T)*(FL1.conj()+np.kron(np.ones((MM*Ns,1)),GL1.T))))+
    #            np.sum(np.kron(V1@V2,np.ones((1,MM)))*np.kron(np.ones((Ns,1)),Avec.T)*Tmat.conj().T*(FC.conj().T*(GL1.conj()+FL1.T)*(GL2.conj()+FL2.T)+
    #            np.kron(CL1.conj(),np.ones((1,MM*Ns)))*(GL2.conj()+FL2.T)+np.kron(CL2.conj(),np.ones((1,MM*Ns)))*(GL1.conj()+FL1.T)))+
    #            np.sum((V1@V2)*Rmat*((CsCt+GC*GC.conj().T)*(GL1.conj()+GL1.T)*(GL2.conj()+GL2.T)+np.kron(CL1.conj(),CL2.T)+np.kron(CL2.conj(),CL1.T)+
    #            (GL2.conj()+GL2.T)*(np.kron(CL1.conj(),np.ones((1,Ns)))*GC+np.kron(np.ones((Ns,1)),CL1.T)*GC.conj().T)+
    #            (GL1.conj()+GL1.T)*(np.kron(CL2.conj(),np.ones((1,Ns)))*GC+np.kron(np.ones((Ns,1)),CL2.T)*GC.conj().T))))+sysfun(V1@V2)*np.sum(lambda_kt1*lambda_kt2.conj())
    
        
    AA=y[0:(MM*Ns*NN)].reshape(MM,Ns*NN,order='F')
    FF=y[(MM*Ns*NN):(MM*Ns*(NN+Nb))].reshape(Nb,MM*Ns,order='F').T
    FFM=FF.conj()@FF.T
    FFMd=np.diag(FFM).reshape(MM*Ns,1)
    Smat=np.exp(FFM-0.5*(FFMd+FFMd.T))
    lambda_kt1=lambda_k*np.exp(-1j*omega_k*t)


    FL1=(FF@lambda_kt1).reshape(MM*Ns,1)
 


    Avec=AA.reshape(Ns*MM*NN,1,order='F')
    Rhov=np.kron(Avec.conj(),Avec.T)

    normf=sysfun(np.eye(Ns*NN))
    pop1=sysfun(sz1)
    pop2=sysfun(sz2)
    pop3=sysfun(ada)

    
    phnum=np.diag(np.kron(np.ones((NN,1)),FF).conj().T@(Rhov*np.kron(np.ones((NN,NN)),Smat)*np.kron(np.eye(Ns*NN),np.ones((MM,MM))))@np.kron(np.ones((NN,1)),FF))



    h2mean=sysfun(Hs2) #+hvmean(HV1,FL1)+0.25*h12mean(V1,V1,FL1,FL1,lambda_kt1,lambda_kt1)

    return (pop1,pop2,pop3,normf,h2mean,phnum)

def corrfun(y1,y2,MM,Ns,Nb,sigmaz):
    AA1=y1[0:(MM*Ns)].reshape(MM,Ns,order='F')
    FF1=y1[(MM*Ns):(MM*Ns*(1+Nb))].reshape(Nb,MM*Ns,order='F').T
    AA2=y2[0:(MM*Ns)].reshape(MM,Ns,order='F')
    FF2=y2[(MM*Ns):(MM*Ns*(1+Nb))].reshape(Nb,MM*Ns,order='F').T
    Smat=np.exp(FF1.conj()@FF2.T-0.5*(np.sum(np.abs(FF1)**2,axis=1).reshape(Ns*MM,1)+np.sum(np.abs(FF2)**2,axis=1).reshape(1,Ns*MM)))
    return np.sum((Smat*np.kron(AA1.conj().reshape(Ns*MM,1,order='F'),AA2.reshape(1,Ns*MM,order='F')))*np.kron(sigmaz,np.ones((MM,MM))))