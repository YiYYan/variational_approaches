import numpy as np
from DavydovD1new import DavydovD1new
from observables import observables
from observables import corrfun
#import matplotlib.pyplot as plt
import scipy as sy
import time

def mainfunmd1(para):   
    
    start_time=time.time()
    sigmaz=np.array([[1.0,0.0],[0.0,-1.0]])
    sigmax=np.array([[0.0,1.0],[1.0,0.0]])
    alpha=para[0]
    Delta=1.0/2
    #lambda0=para[2]
    #wcav=para[3]
    #Vd=para[4]
    MM=int(para[1])
    NN=1
    Ns=2
    wc=1.0
    Nmt=int(para[-1])

    #using linear discretization

    #u_k=np.linspace(0,wc,Nmt+1)
    #lambda_k=np.sqrt(alpha*(u_k[1:]**2-u_k[:-1]**2))
    #omega_k=2/3*(u_k[1:]+u_k[:-1]**2/(u_k[1:]+u_k[:-1]))


    def jwfun(x,alpha):
        #return alpha*x*gg/((1.0-x**2)**2+(2*gg*x)**2)
        return 2*alpha*x*np.exp(-x**2/wc**2)

    #wmax=6.0
    #gg=0.3
    #Nf=1-np.exp(-wmax)
    kn=np.arange(0,Nmt+1)
    xk=-wc*np.log(1-kn/Nmt)
    omega_k=-wc*np.log(1-(kn[1:]-0.5)/Nmt)
    lambda_k=np.zeros((Nmt))

    for jj in range(0,Nmt):
        tmp=sy.integrate.quad(jwfun,xk[jj],xk[jj+1],args=(alpha))
        lambda_k[jj]=tmp[0]

    lambda_k=np.sqrt(lambda_k)

    Nb=len(omega_k)


    #omega_k=np.block([omega_k,wcav])
    #lambda_k=np.block([lambda_k,lambda0])

    ac=np.diag(np.sqrt(np.arange(1,NN)),1)

    ada=np.diag(np.arange(0,NN))

    Hs=-0.5*Delta*sigmax
    sz1=sigmaz
    VV1=sz1
    V1j=np.diag(VV1)

    
    AA=(2*np.random.rand(MM,Ns)-1)*1e-4+0.0*1j
    FF=(2*np.random.rand(MM*Ns,Nb)-1)*1e-1

    #psi0=np.kron(np.blcok([1.0,np.zeros((1,NN-1))]),np.array([0.0,0.0,0.0,1.0]))

    AA[0,0]=1.0
    FF[::MM,:]=(2*np.random.rand(1,Nb)-1)*1e-8
    y0=np.block([AA.flatten(order='F'),FF.flatten()])+1j*0.0
    
    #pop1,pop2,pop3,normf,h2mean,phnum=observables(0.0,y0,Hs2,HV1,VV1,omega_k,lambda_k,Ns,NN,MM,Nb,Sz1,Sz2,Phc)


    Dim=Ns*MM
    tspan=[0,30/Delta]
    sol=sy.integrate.solve_ivp(DavydovD1new,tspan,y0,args=(Hs,V1j,lambda_k,omega_k,Ns,NN,MM,Nb,Dim),t_eval=np.linspace(0,30/Delta,501),rtol=1e-5,atol=1e-6)
    nt=len(sol.t)
    szlist=np.zeros((3,nt),dtype='complex128')
    phlist=np.zeros((nt,Nb),dtype='complex128')


    for ii in range(0,nt):
        pop1,pop2,normf,phnum=observables(sol.t[ii],sol.y[:,ii],Ns,NN,MM,Nb,sigmaz,sigmax)
        #err=DavydovD1e1qerr(sol.t[ii],sol.y[:,ii],Hs,V1j,lambda_k,omega_k,Ns,MM,Nb,Dim)
        szlist[:,ii]=np.array([pop1,pop2,normf]).copy()
        phlist[ii,:]=phnum.copy()




    np.savez('MM_'+str(MM)+'alpha_'+str(alpha)+'NoM'+str(Nb)+'Delta'+str(Delta)+'test.npz',tt=sol.t,szlist=szlist,phlist=phlist,wk=omega_k)

    end_time=time.time()
    print(end_time-start_time)

    #plt.plot(sol.t,szlist[0])
    #plt.show()
