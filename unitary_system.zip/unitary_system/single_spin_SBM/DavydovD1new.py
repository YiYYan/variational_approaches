import numpy as np
import scipy as sy
def DavydovD1new(t,y,Hs,V1j,lambda_k,omega_k,Ns,NN,MM,Nb,Dim):
    AA=y[0:(MM*Ns*NN)].reshape(MM,Ns*NN,order='F')
    FF=y[(MM*Ns*NN):(MM*Ns*(NN+Nb))].reshape(Nb,MM*Ns,order='F').T
    FFM=FF.conj()@FF.T
    FFMd=np.diag(FFM).reshape(MM*Ns,1)
    Smat=np.exp(FFM-0.5*(FFMd+FFMd.T))+1e-10*np.eye(Dim)
    lambda_kt1=lambda_k*np.exp(-1j*omega_k*t)
    dAA=np.zeros((MM,Ns*NN),dtype='complex128')
    dFF=np.zeros((MM*Ns,Nb),dtype='complex128')
    for jj in range(0,Ns):
        Smatj=Smat[(MM*jj):((jj+1)*MM),(MM*jj):((jj+1)*MM)]+1e-10*np.eye(MM)
        FFj=FF[(MM*jj):((jj+1)*MM),:]
        Aj=AA[:,jj:(Ns*NN):Ns]
        FL1=(FFj@lambda_kt1).reshape(MM,1)
        FFD=np.kron(np.kron(np.ones((1,MM)),FFj.conj()),np.ones((Nb,1)))
        LFmatj=np.kron(np.ones((NN,1)),np.kron(Smatj,np.ones((1,Nb))))*np.kron(Aj.T,FFj.conj())
        
        Mattjj=np.block([[np.kron(np.eye(NN),Smatj),LFmatj],
                         [LFmatj.conj().T,np.kron((Aj.conj()@Aj.T)*Smatj,np.ones((Nb,Nb)))*(np.kron(np.ones((MM,MM)),np.eye(Nb))+FFD*FFD.conj().T)]])
        
        ColAj=((np.kron(Hs[jj:(Ns*NN):Ns,:],np.ones((MM,MM)))*np.kron(np.ones((NN,NN)),Smat[(MM*jj):(MM*(jj+1)),:]))@AA.reshape(NN*MM*Ns,1,order='F')+
              (0.5*V1j[jj]*((FL1.T+FL1.conj())*Smatj)@Aj).reshape(NN*MM,1,order='F'))
      

        ColFj=((np.kron(Aj.conj()@Hs[jj:(Ns*NN):Ns,:],np.ones((1,MM)))*np.kron(np.ones((1,NN)),Smat[(MM*jj):(MM*(jj+1)),:])*np.kron(np.ones((MM,1)),AA.reshape(1,MM*Ns*NN,order='F')))@np.kron(np.ones((NN,1)),FF)+
              0.5*V1j[jj]*np.kron(np.sum(Smatj*(Aj.conj()@Aj.T),axis=1).reshape(MM,1),lambda_kt1.conj().reshape(1,Nb))+
              0.5*V1j[jj]*((Aj.conj()@Aj.T)*Smatj*(FL1.T+FL1.conj()))@FFj)
                
    
        
        dytmp=np.linalg.solve(Mattjj,-1j*np.block([[ColAj],[ColFj.reshape(MM*Nb,1)]]))

        dFFj=dytmp[(NN*MM):(MM*(Nb+NN))].reshape(Nb,MM,order='F').T
        dAj=dytmp[0:(NN*MM)].reshape(MM,NN,order='F')+Aj*np.real(np.sum(dFFj*FFj.conj(),axis=1)).reshape(MM,1)

        dAA[:,jj:(NN*Ns):Ns]=dAj
        dFF[(MM*jj):(MM*(jj+1)),:]=dFFj


    return np.block([dAA.flatten(order='F'),dFF.flatten()])