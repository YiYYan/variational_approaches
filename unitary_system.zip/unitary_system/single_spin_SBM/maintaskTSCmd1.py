import numpy as np
from mainfunmd1 import mainfunmd1

# alpha,MM,lambda0,wcav,Vd,Nmt

paralist=np.array([[0.5,12,200]])

nn,mm=paralist.shape

for ii in range(0,nn):
    mainfunmd1(paralist[ii])
