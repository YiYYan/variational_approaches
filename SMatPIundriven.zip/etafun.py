import numpy as np
import scipy as sy
#import matplotlib.pyplot as plt

def etafun(alpha,beta,wc,dt,dKmax,wmax):
    def jwfun(x,alpha,wc):
        return 2*alpha*x*np.exp(-x**2/wc**2)
    
    def coth(x):
        if beta>100:
            return 1.0
        else:
            return np.cosh(x)/np.sinh(x)
    
    etamatkk=np.zeros((2),dtype='complex128')
    etamatNk=np.zeros((dKmax),dtype='complex128')
    etamatkkp=np.zeros((dKmax),dtype='complex128')
    etamatN0=np.zeros((dKmax),dtype='complex128')

    
    etamatkk[1]=0.25*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*(2*coth(0.5*beta*x)*np.sin(0.25*x*dt)**2),0.0,wmax)[0]+0.25j*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*(np.sin(0.5*x*dt)),0.0,wmax)[0]
    etamatkk[0]=(0.25*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*(2*coth(0.5*beta*x)*np.sin(0.5*x*dt)**2),0.0,wmax)[0]+1j*0.25*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*(np.sin(x*dt)),0.0,wmax)[0])


    for jj in range(1,dKmax+1):
        etamatNk[jj-1]=(sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*(coth(0.5*beta*x)*np.cos((jj-0.25)*x*dt))*np.sin(.5*x*dt)*np.sin(0.25*x*dt),0,wmax)[0]-1j*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*np.sin((jj-0.25)*x*dt)*np.sin(.5*x*dt)*np.sin(0.25*x*dt),0,wmax)[0])
        etamatkkp[jj-1]=(sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*coth(0.5*beta*x)*np.cos(jj*x*dt)*np.sin(0.5*x*dt)**2,0,wmax)[0]-1j*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*np.sin(jj*x*dt)*np.sin(0.5*x*dt)**2,0,wmax)[0])
        etamatN0[jj-1]=(sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*(coth(0.5*beta*x)*np.cos((jj-0.5)*x*dt))*np.sin(0.25*x*dt)**2,0,wmax)[0]-1j*sy.integrate.quad(lambda x: jwfun(x,alpha,wc)/x**2*np.sin((jj-0.5)*x*dt)*np.sin(0.25*x*dt)**2,0,wmax)[0])

    #return etamatkk,etamatNk,etamatkkp,etamatN0
    
    #etamatkk=np.zeros((2),dtype='complex128')
    #etamatNk=np.zeros((dKmax),dtype='complex128')
    #etamatkkp=np.zeros((dKmax),dtype='complex128')
    #etamatN0=np.zeros((dKmax),dtype='complex128')

    
    #etamatkk[0]=0.25*(gg/wc)**2*(1-np.exp(-1j*wc*dt))   #eta_{kk}   (0<k<N)
    #etamatkk[1]=0.25*(gg/wc)**2*(1-np.exp(-1j*0.5*wc*dt))   #eta_{00}=eta_{NN}


    #for jj in range(1,dKmax+1):
    #    etamatNk[jj-1]=(gg/wc)**2*np.sin(0.5*wc*dt)*np.sin(0.25*wc*dt)*np.exp(-1j*(jj-0.25)*wc*dt)
    #    etamatkkp[jj-1]=(gg/wc)**2*np.sin(0.5*wc*dt)**2*np.exp(-1j*jj*wc*dt)
    #    etamatN0[jj-1]=(gg/wc)**2*np.sin(0.25*wc*dt)**2*np.exp(-1j*(jj-0.5)*wc*dt)

    return etamatkk,etamatNk,etamatkkp,etamatN0

if __name__=='__main__':
    #debug
    test1,test2,test3,test4=etafun(0.2,200.0,1.0,0.25,5,150)