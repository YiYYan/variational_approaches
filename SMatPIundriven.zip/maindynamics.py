import numpy as np
from etafun import etafun
from FFmat import FFmat
from smallmatrixcorrfun import Matrixfun, corrfun, intcorr, dynfun
import matplotlib.pyplot as plt
import scipy as sy

import time as time
t0=time.time()
alpha=0.1
beta=20
wc=1.0
dt=1.0
Delta=0.1
NN=300
dKmax=11
sdim=4
etamatkk,etamatNk,etamatkkp,etamatN0=etafun(alpha,beta,wc,dt,dKmax,10*wc)

skp=np.kron(np.array([1.0,-1.0]),np.array([1.0,1.0])).reshape(1,sdim)
skn=np.kron(np.array([1.0,1.0]),np.array([1.0,-1.0])).reshape(1,sdim)
sigmax=np.array([[0.0,1.0],[1.0,0.0]])
Hs=-0.5*Delta*sigmax

KKmat,I0LR,I0C,IdkC,IdkR,IdkLR=FFmat(etamatkk,etamatNk,etamatkkp,etamatN0,skp,skn,sdim,dKmax,Hs,dt)


#MMatrix0=np.zeros((dKmax,sdim,sdim),dtype='complex128')
#MMatrix1=np.zeros((dKmax,sdim,sdim),dtype='complex128')

  
AA10=np.diagflat(I0C)@(KKmat*IdkR[0])@np.diagflat(I0LR)
AAC=np.diagflat(I0C)@(KKmat*IdkC[0])

#if not AAC.flags['C_CONTIGUOUS']:
#    AAC = np.ascontiguousarray(AAC)
#if not AA10.flags['C_CONTIGUOUS']:
#    AA10 = np.ascontiguousarray(AA10)


MMatrix0=Matrixfun(dKmax,sdim,IdkR,IdkC,AAC,AA10)

rho0=np.array([1.0,0.0,0.0,0.0],dtype='complex128')

rhot=dynfun(MMatrix0[1:,0,:,:],MMatrix0[0,:,:,:],dKmax,NN,sdim,rho0)

corr=corrfun(MMatrix0,dKmax,NN,sdim,rho0)


szlist=np.vstack((rhot[0]-rhot[3],rhot[1]+rhot[2],rhot[0]+rhot[3]))


#print(str(MMatrix0[2]))
#print(str(MMatrix1[2]))
tspan=np.arange(0,NN+1)*dt
#plt.plot(tspan,np.real(szlist))

#omega_k=np.array([wc])
#lambda_k=np.array([alpha])
Nmt=300
kn=np.arange(0,Nmt+1)
xk=-wc*np.log(1-kn/Nmt)
wk=-wc*np.log(1-(kn[1:]-0.5)/Nmt)
gk2=np.zeros((Nmt))

def jwfun(x,s,alpha,wc):
    return 2*alpha*x**s*np.exp(-x**2/wc**2)

for jj in range(0,Nmt):
    gk2[jj]=sy.integrate.quad(jwfun,xk[jj],xk[jj+1],args=(1.0,alpha,wc))[0]

sw=intcorr(corr+np.triu(corr,1).T.conj(),tspan,wk,gk2,Nmt,NN+1)

np.savez('SMatPI'+'alpha'+str(alpha)+'beta'+str(beta)+'dKmax'+str(dKmax)+'dt'+str(dt)+'new_sbm.npz',tt=tspan,szlist=szlist,wk=wk,sw=sw,corr=corr)

t1=time.time()
print("time: "+str(t1-t0))
