import numpy as np
from scipy.linalg import expm
from etafun import etafun

def FFmat(etamatkk,etamatNk,etamatkkp,etamatN0,skp,skn,sdim,dKmax,Hs,dt):
    I0C=np.exp(-(skp-skn)*(etamatkk[0]*skp-etamatkk[0].conj()*skn))
    I0LR=np.exp(-(skp-skn)*(etamatkk[1]*skp-etamatkk[1].conj()*skn))

    IdkC=np.zeros((dKmax,sdim,sdim),dtype='complex128')
    IdkR=np.zeros((dKmax,sdim,sdim),dtype='complex128')
    IdkLR=np.zeros((dKmax,sdim,sdim),dtype='complex128')

    for jj in range(0,dKmax):
        IdkC[jj,:,:]=np.exp(-(skp-skn).T*(etamatkkp[jj]*skp-etamatkkp[jj].conj()*skn))
        IdkR[jj,:,:]=np.exp(-(skp-skn).T*(etamatNk[jj]*skp-etamatNk[jj].conj()*skn))
        IdkLR[jj,:,:]=np.exp(-(skp-skn).T*(etamatN0[jj]*skp-etamatN0[jj].conj()*skn))


    KKmat=expm(-1j*Hs*dt)
    KKmat=np.kron(KKmat,KKmat.conj())

    return KKmat,I0LR,I0C,IdkC,IdkR,IdkLR

if __name__=='__main__':
    alpha=0.2
    beta=5.0
    wc=1.0
    dt=0.2
    Delta=1.0
    NN=150
    dKmax=7
    sdim=4
    etamatkk,etamatNk,etamatkkp,etamatN0=etafun(alpha,beta,wc,dt,dKmax,20*wc)

    skp=np.kron(np.array([1.0,-1.0]),np.array([1.0,1.0])).reshape(1,sdim)
    skn=np.kron(np.array([1.0,1.0]),np.array([1.0,-1.0])).reshape(1,sdim)
    sigmax=np.array([[0.0,1.0],[1.0,0.0]])
    Hs=-0.5*Delta*sigmax

    KKmat,I0LR,I0C,IdkC,IdkR,IdkLR=FFmat(etamatkk,etamatNk,etamatkkp,etamatN0,skp,skn,sdim,dKmax,Hs,dt)