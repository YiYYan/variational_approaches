import numpy as np
from numba import njit

@njit("int64[:](int64[:],int64)")
def pathadd(path,kk):
    if path[kk]==3:
        path[kk]=0
        pathadd(path,kk-1)
    else: 
        path[kk]=path[kk]+1
    return path

@njit('complex128[:,:](int64[:],int64,int64,int64,complex128[:,:,:],complex128[:,:,:],complex128[:,:],complex128[:,:])')
def iMMatfun(path,sk,s0,kk,IdkC,IdkR,AAC,mmatlistk0):
    tmp=1.0
    tmp2=np.zeros((2,kk-2),dtype='complex128')
    for jj in np.arange(2,kk):
        tmp=tmp*IdkC[jj-1,sk,path[-jj]]
        if jj-2==0:
            tmp2[:,jj-2]=np.array([IdkR[kk-jj,path[-1],s0]-1,IdkC[kk-jj,path[-1],s0]-1])
        else:
            tmp2[:,jj-2]=IdkC[kk-jj,path[-1],path[jj-3]]-1

    tmp3=tmp
    mmatlist=np.zeros((2,kk-1),dtype='complex128')
    for nn in np.arange(0,kk-1):
        if nn==0:
            mmatlist[:,nn]=np.array([IdkR[kk-2,path[-1],s0]*mmatlistk0[0,0]*tmp,IdkC[kk-2,path[-1],s0]*mmatlistk0[1,0]*tmp])
        elif nn==kk-2:
            mmatlist[:,nn]=np.sum(mmatlistk0*tmp2,axis=1)
        else:
            tmp3=tmp3/IdkC[kk-nn-1,sk,path[nn-1]]
            mmatlist[:,nn]=np.sum(mmatlistk0[:,0:(nn+1)]*np.hstack((tmp2[:,0:nn],np.array([[IdkC[kk-2-nn,path[-1],path[nn-1]]],[IdkC[kk-2-nn,path[-1],path[nn-1]]]]))),axis=1)*tmp3

    return mmatlist



#@njit('complex128[:](int64[:],int64,complex128[:,:,:],complex128[:,:,:],complex128[:,:],complex128[:,:])')
#def SMatfun(path,kk,IdkR,IdkC,AAC,AA10):

    #tmp=AAC[path[3],path[2]]*AAC[path[2],path[1]]*AA10[path[1],path[0]]
    #tmpk1=AAC[path[3],path[2]]*AAC[path[2],path[1]]*AAC[path[1],path[0]]
    #mmatlistk0=np.array([[IdkR[1,path[2],path[0]]*IdkC[1,path[3],path[1]],(IdkR[1,path[2],path[0]]-1)],
    #                     [IdkC[1,path[2],path[0]]*IdkC[1,path[3],path[1]],(IdkC[1,path[2],path[0]]-1)]])

    #if kk==3:
    #    tmpMMk0_sks0=np.sum(mmatlistk0*np.array([[IdkR[2,path[3],path[0]]-1,IdkC[1,path[3],path[1]]-1],
    #                                             [IdkC[2,path[3],path[0]]-1,IdkC[1,path[3],path[1]]-1]]),axis=1)
    #    return tmpMMk0_sks0
    #else:
    #    for nn in np.arange(4,kk+1):
    #        mmatlistk0=iMMatfun(path[1:nn],path[nn],path[0],nn,IdkC,IdkR,AAC,mmatlistk0)

    #    tmp2=np.zeros((2,kk-1),dtype='complex128')
    #    for jj in np.arange(0,kk-1):
    #        if jj==0:
    #            tmp2[:,jj]=np.array([IdkR[kk-jj-1,path[-1],path[0]]-1,IdkC[kk-jj-1,path[-1],path[0]]-1])
    #        else:
    #            tmp2[:,jj]=IdkC[kk-jj-1,path[-1],path[jj]]-1
        
    #    tmpMMk0_sks0=np.sum(tmp2*mmatlistk0,axis=1)

    #    return tmpMMk0_sks0

@njit('complex128[:,:,:,:](int64,int64,complex128[:,:,:],complex128[:,:,:],complex128[:,:],complex128[:,:])')
def Matrixfun(dKmax,sdim,IdkR,IdkC,AAC,AA10):
    
    tmpMMk0=np.zeros((dKmax+1,dKmax,sdim,sdim),dtype='complex128')
    kk_node=1
    skp=np.array([1.0,1.0,-1.0,-1.0])

    tmpMMk0[1,0,:,:]=AA10
    tmpMMk0[2,0,:,:]=(IdkR[1]-1)*(AAC@AA10)
    tmpMMk0[2,1,:,:]=(IdkR[1]-1)*((np.array([[1.0],[1.0],[-1.0],[-1.0]])*AAC)@AA10)
    tmpMMk0[0,0,:,:]=AAC
    tmpMMk0[0,1,:,:]=(IdkC[1]-1)*(AAC@AAC)
    tmpMMk0[1,1,:,:]=(IdkC[1]-1)*((np.array([[1.0],[1.0],[-1.0],[-1.0]])*AAC)@AAC)

    path=np.zeros((dKmax+1),dtype='int64')
    for jj in range(0,4**(dKmax+1)):
        tmpk0=AAC[path[-4],path[-3]]*AAC[path[-3],path[-2]]*AA10[path[-2],path[-1]]
        tmpk1=AAC[path[-4],path[-3]]*AAC[path[-3],path[-2]]*AAC[path[-2],path[-1]]

        mmatlistk0=np.array([[IdkR[1,path[-3],path[-1]]*IdkC[1,path[-4],path[-2]],(IdkR[1,path[-3],path[-1]]-1)],
                             [IdkC[1,path[-3],path[-1]]*IdkC[1,path[-4],path[-2]],(IdkC[1,path[-3],path[-1]]-1)]])
        if kk_node<=256:
            tmpMM=np.sum(mmatlistk0*np.array([[IdkR[2,path[-4],path[-1]]-1,IdkC[1,path[-4],path[-2]]-1],
                                                  [IdkC[2,path[-4],path[-1]]-1,IdkC[1,path[-4],path[-2]]-1]]),axis=1)
            for Nk in np.arange(0,3):
                if Nk==0:
                    tmpMMk0[3,Nk,path[-4],path[-1]]+=tmpk0*tmpMM[0]
                    tmpMMk0[Nk,2,path[-4],path[-1]]+=tmpk1*tmpMM[1]
                else:
                    tmpMMk0[3,Nk,path[-4],path[-1]]+=skp[path[-Nk-1]]*tmpk0*tmpMM[0]
                    tmpMMk0[Nk,2,path[-4],path[-1]]+=skp[path[-Nk-1]]*tmpk1*tmpMM[1]                   
        
        for kk in np.arange(4,dKmax+1):
            tmpk0*=AAC[path[-kk-1],path[-kk]]
            tmpk1*=AAC[path[-kk-1],path[-kk]]
            path_kk=path[-(kk+1):]
            mmatlistk0=iMMatfun(path_kk[1:-1][::-1],path[-kk-1],path[-1],kk,IdkC,IdkR,AAC,mmatlistk0)
            if kk_node<=4**(kk+1):
                tmp2=np.zeros((2,kk-1),dtype='complex128')
                for jj in np.arange(0,kk-1):
                    if jj==0:
                        tmp2[:,jj]=np.array([IdkR[kk-jj-1,path[-kk-1],path[-1]]-1,IdkC[kk-jj-1,path[-kk-1],path[-1]]-1])
                    else:
                        tmp2[:,jj]=IdkC[kk-jj-1,path[-kk-1],path[-jj-1]]-1
        
                tmpMM=np.sum(tmp2*mmatlistk0,axis=1)
                for Nk in np.arange(0,kk):
                    if Nk==0:
                        tmpMMk0[kk,Nk,path[-kk-1],path[-1]]+=tmpk0*tmpMM[0]
                        tmpMMk0[Nk,kk-1,path[-kk-1],path[-1]]+=tmpk1*tmpMM[1]
                    else:
                        tmpMMk0[kk,Nk,path[-kk-1],path[-1]]+=skp[path[-Nk-1]]*tmpk0*tmpMM[0]
                        tmpMMk0[Nk,kk-1,path[-kk-1],path[-1]]+=skp[path[-Nk-1]]*tmpk1*tmpMM[1]
            
            
        path=pathadd(path,dKmax)
        kk_node=kk_node+1

    return tmpMMk0

@njit('complex128[:,:](complex128[:,:,:],complex128[:,:,:],int64,int64,int64,complex128[:])')
def dynfun(MMmatrix0,MMmatrix1,dKmax,NN,sdim,rho0):
    UUmat=np.zeros((dKmax,sdim,sdim),dtype='complex128')
    UUmat[0]=MMmatrix0[0]
    rhot=np.zeros((sdim,NN+1),dtype='complex128')
    rhot[:,0]=rho0
    rhot[:,1]=UUmat[0]@rho0
    for rr in np.arange(1,dKmax):
        UUmat[rr]=MMmatrix0[rr]
        for mm in np.arange(0,rr):
            UUmat[rr]=UUmat[rr]+MMmatrix1[rr-mm-1]@UUmat[mm]

        rhot[:,rr+1]=UUmat[rr]@rho0

    for rr in np.arange(dKmax,NN):
        UUtmp=MMmatrix1[-1]@UUmat[0]
        for mm in np.arange(0,dKmax-1):
            UUtmp=UUtmp+MMmatrix1[dKmax-mm-2]@UUmat[mm+1]
        UUmat[0:-1,:,:]=UUmat[1:,:,:]
        UUmat[-1,:,:]=UUtmp
        rhot[:,rr+1]=UUtmp@rho0

    return rhot     

@njit('complex128[:,:](complex128[:,:,:,:],int64,int64,int64,complex128[:])')
def corrfun(MMmatrix00,dKmax,NN,sdim,rho00):
    UUmat=np.zeros((dKmax,sdim,sdim),dtype='complex128')
    corr=np.zeros((NN+1,NN+1),dtype='complex128')
    corr[0,0]=1.0
    for Nk in np.arange(0,NN+1):
        if Nk==0:
            rho0=np.array([1.0,1.0,-1.0,-1.0])*rho00
        else:
            rho0=rho00
        if Nk==1:
            UUmat[0]=np.array([[1.0],[1.0],[-1.0],[-1.0]])*MMmatrix00[1,0]
        else:
            UUmat[0]=MMmatrix00[1,0]
    
        if 1>=Nk:
            rhot=UUmat[0]@rho0
            corr[Nk,1]=rhot[0]-rhot[3]

        for rr in range(1,dKmax):
            if Nk>dKmax or rr+1<Nk:
                UUmat[rr]=MMmatrix00[rr+1,0]
            elif rr+1==Nk:
                UUmat[rr]=np.array([[1.0],[1.0],[-1.0],[-1.0]])*MMmatrix00[rr+1,0]
            else:
                UUmat[rr]=MMmatrix00[rr+1,Nk]
            for mm in np.arange(0,rr):
                if rr+1<Nk or mm+1>=Nk:
                    MMmatrix1=MMmatrix00[0,rr-mm-1]
                elif rr+1==Nk:
                    MMmatrix1=np.array([[1.0],[1.0],[-1.0],[-1.0]])*MMmatrix00[0,rr-mm-1]
                else:
                    MMmatrix1=MMmatrix00[Nk-1,rr-mm-1]
                UUmat[rr]=UUmat[rr]+MMmatrix1@UUmat[mm]

            if rr+1>=Nk:
                rhot=UUmat[rr]@rho0
                corr[Nk,rr+1]=rhot[0]-rhot[3]

        for rr in range(dKmax,NN):
            if rr+1<Nk or rr-dKmax+1>=Nk:
                UUtmp=MMmatrix00[0,-1]@UUmat[0]
            elif rr+1==Nk:
                UUtmp=(np.array([[1.0],[1.0],[-1.0],[-1.0]])*MMmatrix00[0,-1])@UUmat[0]
            else:
                UUtmp=MMmatrix00[Nk-rr+dKmax-1,-1]@UUmat[0]
            for mm in np.arange(0,dKmax-1):
                if rr+1<Nk or rr-dKmax+mm+2>=Nk:
                    MMmatrix11=MMmatrix00[0,dKmax-mm-2]
                elif rr+1==Nk:
                    MMmatrix11=np.array([[1.0],[1.0],[-1.0],[-1.0]])*MMmatrix00[0,dKmax-mm-2]
                else:
                    MMmatrix11=MMmatrix00[Nk-rr+dKmax-mm-2,dKmax-mm-2]

                UUtmp=UUtmp+MMmatrix11@UUmat[mm+1]
            
            UUmat[0:-1,:,:]=UUmat[1:,:,:]
            UUmat[-1,:,:]=UUtmp
            if rr+1>=Nk:
                rhot=UUtmp@rho0
                corr[Nk,rr+1]=rhot[0]-rhot[3]

    return corr

def intcorr(corrf,tspan,omega_k,lambda_k2,Nb,Nt):
    TT1,TT2=np.meshgrid(tspan,tspan)
    sw=np.zeros((Nt-50,Nb),dtype='complex128')
    for nn in np.arange(50,Nt):
        for mm in range(0,Nb):
            sw[nn-50,mm]=0.25*lambda_k2[mm]*np.trapezoid(np.trapezoid(corrf[0:nn+1,0:nn+1]*np.exp(-1j*omega_k[mm]*(TT1[0:nn+1,0:nn+1]-TT2[0:nn+1,0:nn+1])),tspan[0:nn+1]),tspan[0:nn+1])

    return sw