import numpy as np
#from mainmd2funsbm import mainmd2funsbm
from mainmd1funsbm import mainmd1funsbm
import time


#para: alpha
#para=np.array([[0.1,0.1,0.1]])

beta='20_p0013'
alpha=0.5
#filename='Ohmic_alpha0p3_beta5_NN5_En10_En3_p00084.txt'           
filename='Ohmic_alpha0p5_NN6_beta20_En7_En3_p0013.txt'
#filename='Ohmic_alpha0p3_NN7_En7_En3_p00009.txt'
#filename='Ohmic_alpha0p1_beta20_NN5_En9_En3_p00080.txt'
#filename=['Ohmic_alpha0p1_NN7_En10_En3_p0010.txt','Ohmic_alpha0p3_NN7_En7_En3_p00009.txt','Ohmic_alpha0p5_NN7_En11_En3_p0020.txt']

MMlist=np.array([7],dtype='int')
#nn,mm=para.shape

ll=MMlist.size


for ii in range(0,ll):
    time0=time.time()
    #mainmd2funsbm(MMlist[ii],alpha,filename)
    mainmd1funsbm(MMlist[ii],alpha,beta,filename)
    time1=time.time()
    print(time1-time0)