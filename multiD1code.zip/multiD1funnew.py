import numpy as np
import scipy as sy

def DavydovD1(t,y,MM,Ns,Nb,LL,VV,WW,lambda_k,omega_k,gamma_k,Ad,wd):

    def colafun1(jj,FL,FFL,VV,AAM):
        return np.diag(FL.conj())@mff[jj::Ns,:]@(np.kron((VV[jj,:].reshape(1,Ns)*AAM).reshape(MM,MM*Ns),np.ones((Ns,1)))*JIM)@mgg[:,jj::Ns]+mff[jj::Ns,:]@np.diag(FFL)@(np.kron((VV[:,jj].conj().reshape(1,Ns)*AAM).reshape(MM,MM*Ns),np.ones((Ns,1)))*JIM)@mgg[:,jj::Ns]

    def colafun2(jj,GL,GGL,WW,AAM):
        return mff[jj::Ns,:]@(np.kron((WW[jj,:].reshape(1,Ns)*AAM).reshape(MM,MM*Ns),np.ones((Ns,1)))*JIM)@np.diag(GGL)@mgg[:,jj::Ns]+mff[jj::Ns,:]@(np.kron((WW[:,jj].conj().reshape(1,Ns)*AAM).reshape(MM,MM*Ns),np.ones((Ns,1)))*JIM)@mgg[:,jj::Ns]@np.diag(GL.conj())
    
    Ls=LL-1j*Ad*np.cos(wd*t)*(VV-WW)

    AA=y[0:(MM**2*Ns)].reshape(MM,MM,Ns)
    FF=y[(MM**2*Ns):(Nb*MM*Ns+MM**2*Ns)].reshape(MM*Ns,Nb)
    GG=y[(Nb*Ns*MM+MM**2*Ns):].reshape(MM*Ns,Nb)

    tmpff=FF.conj()@FF.T
    mff=np.exp(tmpff-0.5*(np.diag(tmpff).reshape(Ns*MM,1)+np.diag(tmpff).reshape(1,Ns*MM)))+1e-10*np.eye(MM*Ns)
    tmpgg=GG@GG.conj().T
    mgg=np.exp(tmpgg-0.5*(np.diag(tmpgg).reshape(Ns*MM,1)+np.diag(tmpgg).reshape(1,Ns*MM)))+1e-10*np.eye(MM*Ns)

    FFe=np.kron(FF.reshape(MM,Ns*Nb),np.ones((MM,1))).reshape(MM**2*Ns,Nb)
    GGe=np.kron(np.ones((MM,1)),GG)
    tmpffe=FFe.conj()@FFe.T
    Smat=np.exp(tmpffe-0.5*(np.diag(tmpffe).reshape(-1,1)+np.diag(tmpffe).reshape(1,-1)))*np.kron(np.ones((MM,MM)),mgg.T)


    AAR=AA.reshape(1,MM**2*Ns)
    AAM=AA.reshape(MM**2,Ns)
    lambda_kt=lambda_k*np.exp(-1j*omega_k*t)
    gamma_kt=gamma_k*np.exp(-1j*omega_k*t)
    FFeL=FFe@lambda_kt
    GGeL=GGe@lambda_kt.conj()
    tmpF=(np.diag(FFeL.conj())@np.kron(np.ones((MM**2,MM**2)),-0.5j*VV)+np.kron(np.ones((MM**2,MM**2)),-0.5j*VV.conj().T)@np.diag(FFeL)+np.diag(GGeL.conj())@np.kron(np.ones((MM**2,MM**2)),0.5j*WW.conj().T)+np.kron(np.ones((MM**2,MM**2)),0.5j*WW)@np.diag(GGeL))
    tmpFR=(np.kron(np.ones((MM**2,MM**2)),Ls)+tmpF)*np.kron(AAR.T.conj(),AAR)*Smat
    dAA=np.zeros((MM**2,Ns),dtype='complex128')
    dFF=np.zeros((MM*Ns,Nb),dtype='complex128')
    dGG=np.zeros((MM*Ns,Nb),dtype='complex128')

    FFL=FF@lambda_kt
    FFN=FF@gamma_kt
    GGL=GG@lambda_kt.conj()
    GGN=GG@gamma_kt.conj()
    JIM=np.kron(np.ones((MM,MM)),np.eye(Ns))

    for jj in range(0,Ns):
        mffjj=mff[jj::Ns,jj::Ns]+1e-10*np.eye(MM)
        mggjj=mgg[jj::Ns,jj::Ns]+1e-10*np.eye(MM)
        mfgjj=np.kron(mffjj,mggjj.T)+1e-10*np.eye(MM**2)
        FFjj=FF[jj::Ns,:]
        GGjj=GG[jj::Ns,:]
        tmp1=np.zeros((MM*Nb,MM),dtype='complex128')
        tmp2=np.zeros((MM,MM*Nb),dtype='complex128')
        for kk in range(0,MM):
            tmp1=tmp1+np.tensordot(np.kron(mffjj[:,kk],FFjj[kk,:]),AA[kk,:,jj],axes=0)
            tmp2=tmp2+np.tensordot(AA[:,kk,jj].conj(),np.kron(mggjj[:,kk],GGjj[kk,:].conj()),axes=0)

        ATT=(AA[:,:,jj]@mggjj).T
        SA=mffjj@AA[:,:,jj]
        FFmj=np.kron(np.kron(np.ones((1,MM)),FFjj.conj()),np.ones((Nb,1)))
        GGmj=np.kron(np.kron(np.ones((1,MM)),GGjj.conj()),np.ones((Nb,1)))
        Lm01=np.kron(np.ones((MM,1)),np.kron(ATT,np.ones((1,Nb))))*np.kron(np.kron(np.ones((1,MM)),FFjj.conj()),np.ones((MM,1)))*np.kron(mffjj,np.ones((MM,Nb)))
        Lm02=np.kron(np.kron(np.ones((MM,1)),mggjj.T),np.ones((1,Nb)))*np.kron(SA,np.ones((MM,Nb)))*np.kron(np.ones((MM,MM)),GGjj.conj())
        Lm11=np.kron(mffjj*(AA[:,:,jj].conj()@ATT),np.ones((Nb,Nb)))*(np.kron(np.ones((MM,MM)),np.eye(Nb))+FFmj*FFmj.T.conj())
        Lm12=np.kron(tmp1,np.ones((1,Nb)))*np.kron(tmp2,np.ones((Nb,1)))
        Lm22=np.kron(mggjj.T*(AA[:,:,jj].conj().T@SA),np.ones((Nb,Nb)))*(np.kron(np.ones((MM,MM)),np.eye(Nb))+GGmj*GGmj.T.conj())

        
        Matt=np.block([[mfgjj,Lm01,Lm02],
                       [Lm01.conj().T,Lm11,Lm12],
                       [Lm02.conj().T,Lm12.conj().T,Lm22]])

        FL=FFL[jj::Ns]
        Fn=FFN[jj::Ns]
        GL=GGL[jj::Ns]
        Gm=GGN[jj::Ns]

        tmpA=np.kron((VV[jj,:].reshape(1,Ns)*AAM).reshape(MM,MM*Ns),np.ones((Ns,1)))*JIM
        tmpB=np.kron((WW[:,jj].conj().reshape(1,Ns)*AAM).reshape(MM,MM*Ns),np.ones((Ns,1)))*JIM

        AAnmkl=np.tensordot(AA[:,:,jj].reshape(-1).conj(),AA[:,:,jj].reshape(-1),axes=0)
        FFklnm=np.kron(np.ones((MM**2,1)),np.kron(Fn.reshape(1,MM),Gm.reshape(1,MM)))-0.5*(np.kron(np.kron(Fn.conj().reshape(MM,1),Fn.reshape(1,MM)),np.ones((MM,MM)))+np.kron(np.ones((MM,MM)),np.kron(Gm.conj().reshape(MM,1),Gm.reshape(1,MM))))

        colAjj=np.sum(np.kron(np.ones((MM**2,MM**2)),Ls[jj,:])*AAR*Smat[jj::Ns,:],axis=1)-0.5j*colafun1(jj,FL,FFL,VV,AA).reshape(-1)+0.5j*colafun2(jj,GL,GGL,WW,AAM).reshape(-1)+(FFklnm*mfgjj)@AA[:,:,jj].reshape(-1)

        colFjj=np.sum((tmpFR[jj::Ns,:]@FFe).reshape(MM,MM,Nb),axis=1)+np.tensordot(np.diag(mff[jj::Ns,:]@tmpA@mgg[:,jj::Ns]@AA[:,:,jj].conj().T),-0.5j*lambda_kt.conj(),axes=0)+np.sum((FFklnm*AAnmkl*mfgjj).reshape(MM,MM,MM,MM),axis=(1,3))@FFjj-0.5*np.tensordot(np.sum(AA[:,:,jj].conj()*(mffjj@np.diagflat(Fn)@AA[:,:,jj]@mggjj),axis=1),gamma_kt.conj(),axes=0)

        colGjj=np.sum((tmpFR[jj::Ns,:]@GGe).reshape(MM,MM,Nb),axis=0)+np.tensordot(np.diag(AA[:,:,jj].conj().T@mff[jj::Ns,:]@tmpB@mgg[:,jj::Ns]),0.5j*lambda_kt,axes=0)+np.sum((FFklnm*AAnmkl*mfgjj).reshape(MM,MM,MM,MM),axis=(0,2))@GGjj-0.5*np.tensordot(np.sum(AA[:,:,jj].conj()*(SA@np.diagflat(Gm)@mggjj),axis=0),gamma_kt,axes=0)

        dytmp=np.linalg.solve(Matt+1e-12*np.eye(MM**2+2*MM*Nb),np.block([colAjj,colFjj.reshape(MM*Nb),colGjj.reshape(MM*Nb)]))

        dFFjj=dytmp[MM**2:(MM**2+MM*Nb)].reshape(MM,Nb)
        dGGjj=dytmp[(MM**2+MM*Nb):].reshape(MM,Nb)
        dAjj=dytmp[0:(MM**2)]+AA[:,:,jj].reshape(-1)*np.real(np.kron(np.sum(dFFjj*FFjj.conj(),axis=1),np.ones((MM)))+np.kron(np.ones((MM)),np.sum(dGGjj*GGjj.conj(),axis=1)))

        dAA[:,jj]=dAjj
        dFF[jj::Ns,:]=dFFjj
        dGG[jj::Ns,:]=dGGjj

    return np.block([dAA.flatten(),dFF.flatten(),dGG.flatten()])