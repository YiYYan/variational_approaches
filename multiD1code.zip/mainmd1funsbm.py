from multiD1fun import DavydovD1
from observablesd1 import observables, cal_corrfun
import numpy as np
import scipy as sy

def mainmd1funsbm(MM,alpha,beta,filename):
    sigmaz=np.array([[1,0],[0,-1]])
    sigmax=np.array([[0,1],[1,0]])
    w0=0.1
    Na=2
    wc=1.0
    wd=w0
    Ad=0.0


    tmp=np.loadtxt(filename)
    omega_k=tmp[0]
    Gamma_k=tmp[1]
    lambda_k=(tmp[2]+1j*tmp[3])

  


    Hs=-0.5*w0*sigmax
    Ls=-1j*np.kron(np.eye(Na),Hs)+1j*np.kron(Hs.T,np.eye(Na))
    VV=sigmaz

    #sp=np.array([[0.0,1.0],[0.0,0.0]])
    #sn=sp.T
    #Hs=0.5*sigmaz
    #Ls=-1j*np.kron(np.eye(Na),Hs)+1j*np.kron(Hs.T,np.eye(Na))+gamma0*(np.kron(sp.T,sn)-0.5*(np.kron(np.eye(2),sp@sn)+np.kron(sp@sn,np.eye(2))))
    #VV=sigmax



    VV1=np.kron(np.eye(Na),VV)
    VV2=np.kron(VV.conj(),np.eye(Na))

    #Ls2=Ls.conj().T@Ls
    #HV=0.5*(Hs@VV+VV@Hs)
    #HVd=0.5*(Hs@VV.conj().T+VV.conj().T@Hs)
    #Hs2=Hs@Hs
    ns=Hs.shape[0]
    Ns=Ls.shape[0]
    Nb=len(omega_k)
    #AA=(2*np.random.rand(MM,MM,ns,ns)-1)*1e-6
    #AA=0.5*(AA+np.transpose(AA,(1,0,3,2)))
    #AA=AA.reshape(MM,MM,Ns)
    #AA=(np.ones((MM,MM,Ns)))*1e-4
    AA=np.zeros((MM,MM,Ns))
    AA[0,0,0]=1.0 #np.array([1.0/2.0,1.0/2.0,1.0/2.0,1.0/2.0])
    FF=(2*np.random.rand(Ns*MM,Nb)-1)*1e-1
    FF[0:Ns,:]=(2*np.random.rand(Ns,Nb)-1)*1e-10
    GG=(2*np.random.rand(MM*Ns,Nb)-1)*1e-1
    GG[0:Ns,:]=(2*np.random.rand(Ns,Nb)-1)*1e-10
    y0=np.concatenate((AA.flatten(),FF.flatten(),FF.flatten()))+1j*0.0

    #observables(y0,MM,Ns,Nb)

    tf=30.0/w0
    tspan=np.linspace(0,tf,401)
    sol=sy.integrate.solve_ivp(DavydovD1,[tspan[0],tspan[-1]],y0,args=(MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k,Ad,wd),t_eval=tspan, rtol=1e-5,atol=1e-6)
    nt=len(sol.t)
    szlist=np.zeros((3,nt),dtype='complex128')
    phlist=np.zeros((nt,Nb),dtype='complex128')


    for ii in range(0,nt):
        pop,popx,normf,phnum=observables(sol.y[:,ii],MM,Ns,Nb)
        #err=DavydovD2err(sol.t[ii],sol.y[:,ii],MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k,wd,Ad)
        szlist[:,ii]=np.array([pop,popx,normf]).copy()
        phlist[ii,:]=phnum.copy()



    gzzfun=np.zeros((nt,nt),dtype='complex128')
    for kk in range(0,nt-1):
        tmp=sol.y[:,kk].copy()
        AA0=tmp[0:(MM**2*Ns)].reshape(MM*MM,Ns)
        #AA0=AA0[:,[1,0,3,2]]
        AA0[:,[1,3]]=-AA0[:,[1,3]]
        yy0=np.block([AA0.flatten(),tmp[MM**2*Ns:]])
        soly2=sy.integrate.solve_ivp(DavydovD1,[tspan[kk],tspan[-1]],yy0,args=(MM,Ns,Nb,Ls,VV1,VV2,lambda_k,omega_k,Gamma_k,Ad,wd),t_eval=tspan[kk:], rtol=1e-5,atol=1e-6)
        for mm in range(0,len(soly2.t)):
            if kk < nt-2:
                gzzfun[kk,kk+mm]=cal_corrfun(soly2.y[:,mm],MM,Ns,Nb)
            elif kk == nt-2:
                gzzfun[kk,-2]=cal_corrfun(soly2.y[:,0],MM,Ns,Nb)
                gzzfun[kk,-1]=cal_corrfun(soly2.y[:,-1],MM,Ns,Nb)


    gzzfun[-1,-1]=1.0

    TT1,TT2=np.meshgrid(tspan,tspan)

    gzzfun=(gzzfun+np.triu(gzzfun,1).conj().T)

    def corrfun(gzzfun,t1,t2,wk):
        return gzzfun*np.exp(-1j*wk*(t1-t2))

    Nmt=300
    wk=np.linspace(0,wc,Nmt)

    nm=nt-1
    phlist2=np.zeros((nt-nm,Nmt),dtype='complex128')

    for jj in range(1,nt-nm+1):
        for kk in range(0,Nmt):
            phlist2[jj-1,kk]=np.trapezoid(np.trapezoid(corrfun(gzzfun[0:nm+jj,0:nm+jj],TT1[0:nm+jj,0:nm+jj],TT2[0:nm+jj,0:nm+jj],wk[kk]),tspan[0:jj+nm]),tspan[0:jj+nm]) 


    #plt.plot(wk,np.real(gk2*sw),omega_k,np.imag(gk2*sw))


    np.savez('MM'+str(MM)+'alpha'+str(alpha)+'beta'+str(beta)+'PM'+str(Nb)+'Ad'+str(Ad)+'wd'+str(wd)+'single_sbmv3.npz',tt=sol.t,szlist=szlist,phlist2=phlist2,wk=wk,gzzfun=gzzfun)

if __name__=="__main__":
    MM=4
    alpha=0.1
    beta=5
    filename='Ohmic_alpha0p1_beta5_NN4_En9_En3_p00049.txt'
    mainmd1funsbm(MM,alpha,beta,filename)
