import numpy as np

def observables(y,MM,Ns,Nb):

    AA=y[0:(MM**2*Ns)].reshape(MM,MM*Ns)
    FF=y[(MM**2*Ns):(Nb*MM*Ns+MM**2*Ns)].reshape(MM*Ns,Nb)
    GG=y[(Nb*Ns*MM+MM**2*Ns):].reshape(MM*Ns,Nb)

    mgf=np.exp(GG@FF.T-0.5*(np.sum(np.abs(GG)**2,axis=1).reshape(MM*Ns,1)+np.sum(np.abs(FF)**2,axis=1).reshape(1,MM*Ns)))

    AAM=np.kron(AA,np.ones((Ns,1)))
    #mgfvec=np.zeros((MM*MM,Ns),dtype='complex128')
    #rr=0
    #for nn in range(0,MM):
    #    for mm in range(0,MM):
    #        mgfvec[rr,:]=np.diag(mgf[mm*Ns:(mm+1)*Ns,nn*Ns:(nn+1)*Ns])
    #        rr+=1

    #pop=np.sum(mgfvec.flatten()*AA.reshape(-1)*np.kron(np.ones((MM**2)),np.array([1.0,0.0,0.0,-1.0])))
    pop=np.sum(mgf.T*AAM*np.kron(np.ones((MM,MM)),np.diag(np.array([1.0,0.0,0.0,-1.0]))))
    popx=np.sum(mgf.T*AAM*np.kron(np.ones((MM,MM)),np.diag(np.array([0.0,1.0,1.0,0.0]))))
    normf=np.sum(mgf.T*AAM*np.kron(np.ones((MM,MM)),np.diag(np.array([1.0,0.0,0.0,1.0]))))
    phnum=np.diag(GG.T@(mgf.T*AAM*np.kron(np.ones((MM,MM)),np.diag(np.array([1.0,0.0,0.0,1.0]))))@FF)

    return (pop,popx,normf,phnum)



def cal_corrfun(y,MM,Ns,Nb):
    
    AA=y[0:(MM**2*Ns)].reshape(MM,MM*Ns)
    FF=y[(MM**2*Ns):(Nb*MM*Ns+MM**2*Ns)].reshape(MM*Ns,Nb)
    GG=y[(Nb*Ns*MM+MM**2*Ns):].reshape(MM*Ns,Nb)

    mgf=np.exp(GG@FF.T-0.5*(np.sum(np.abs(GG)**2,axis=1).reshape(MM*Ns,1)+np.sum(np.abs(FF)**2,axis=1).reshape(1,MM*Ns)))

    AAM=np.kron(AA,np.ones((Ns,1)))

    corr=np.sum(mgf.T*AAM*np.kron(np.ones((MM,MM)),np.diag(np.array([1.0,0.0,0.0,-1.0]))))
    #corr=mgf.T.flatten()@AA@np.array([0.0,0.0,0.0,1.0])
    #corr=mgf.T.flatten()@AA@np.array([1.0,0.0,0.0,-1.0])
    #corr=mgf.T.flatten()@AA@np.array([0.0,1.0,1.0,0.0])

    return corr


#def cal_corrfunjc(y,MM,Ns,Nb):
    
#    AA=y[0:(MM**2*Ns)].reshape(MM*MM,Ns)
#    FF=y[(MM**2*Ns):(Nb*MM+MM**2*Ns)].reshape(MM,Nb)
#    GG=y[(Nb*MM+MM**2*Ns):].reshape(MM,Nb)

#    mgf=np.exp(GG@FF.T-0.5*(np.sum(np.abs(GG)**2,axis=1).reshape(MM,1)+np.sum(np.abs(FF)**2,axis=1).reshape(1,MM)))


    #corr=mgf.T.flatten()@AA@np.array([1.0,0.0,0.0,-1.0])
#    corr=mgf.T.flatten()@AA@np.array([0.0,1.0,0.0,0.0])

#    return corr